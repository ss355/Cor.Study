##### Let's Try to Address the big suggestion by reviewer 2:

# Pre-Section: Loading in the Generated data is we have done the work below already
# Section 1: Generating all the resamples and then making a list with the high row counts
# Section 2: Boxplots of the Original and the median values
# Section 3: Boxplots of the Original and the median values for the different thresholds for MIC, kendall and hoeffding
# Section 4: P Value Work 

##### 

################################### 
# Let us read in the files

high_row_counts_b.distance = read.csv("high_row_counts_b.distance.csv")
high_row_counts_b.pearson = read.csv("high_row_counts_b.pearson.csv")
high_row_counts_hoeffding = read.csv("high_row_counts_hoeffding.csv")
high_row_counts_kendall = read.csv("high_row_counts_kendall.csv")
high_row_counts_m.distance = read.csv("high_row_counts_m.distance.csv")
high_row_counts_m.pearson = read.csv("high_row_counts_m.pearson.csv")
high_row_counts_MIC = read.csv("high_row_counts_MIC.csv")
high_row_counts_spearman = read.csv("high_row_counts_spearman.csv")

high_row_counts_list <- list(
  b.distance    = high_row_counts_b.distance,
  b.pearson     = high_row_counts_b.pearson,
  hoeffding     = high_row_counts_hoeffding,
  kendall       = high_row_counts_kendall,
  m.distance    = high_row_counts_m.distance,
  m.pearson     = high_row_counts_m.pearson,
  MIC           = high_row_counts_MIC,
  spearman      = high_row_counts_spearman
)



high_row_counts_hoeffding_0.3 = read.csv("high_row_counts_hoeffding_0.3.csv")
high_row_counts_kendall_0.6 = read.csv("high_row_counts_kendall_0.6.csv")
high_row_counts_MIC_0.6 = read.csv("high_row_counts_MIC_0.6.csv")

high_row_counts_list_adjusted <- list(
  hoeffding_0.3     = high_row_counts_hoeffding_0.3,
  kendall_0.6       = high_row_counts_kendall_0.6,
  MIC_0.6           = high_row_counts_MIC_0.6
)
################################### 

############### 
# Section 1
############### 

# First Lets Read in the Data
setwd("E:/R/Post.REU") # My Workspace
all_data = read.table(file = "BRCA.53Alive.Normal.380355cg.75col.Aug18.2022.txt", header = TRUE ) # The Original Big Data

# We are interested in seeing how the correlations change if we randomaly rearrange the data
# For simplicity we will use 1000 x 1000
# The reviewer suggests that if it is the "true correlation" highly correlated pairs will become loss their correlation.


# Get the first 1000 for 30N Data
First_1000 = all_data[1:1000, 5:34]
First_1000_t = t(First_1000)


#To convert B into M values
First_1000_M <-log2((First_1000[,])/ (1-First_1000[,]))
First_1000__M_t = t(First_1000_M)

# Load in the packages 
library(Hmisc)
library(purrr)
library(minerva)
library(Pigengene)
library(BiocGenerics)
library(BiocStyle)
library(energy)

# Label function from Before
cor.label <- function(mat) {
  ids <- all_data[1:1000, 1]
  rownames(mat) <- ids
  colnames(mat) <- ids
  mat
}



# Have designed a function to basically run all the correlations since we are going to need to do this on multiple Samples
compute_all_metrics <- function(b_df, m_df, permute = TRUE) {
  
  # Permute rows in parallel if needed
  if (permute) {
    perm_b <- b_df
    perm_m <- m_df
    for (i in seq_len(nrow(b_df))) {
      perm_b[i, ] <- sample(b_df[i, ], replace = FALSE)
    }
    perm_m <-log2(perm_b)/ (1-perm_b) 
    
    b_mat <- t(perm_b)
    m_mat <- t(perm_m)
  } else {
    b_mat <- t(b_df)
    m_mat <- t(m_df)
  }
  
  # Note these are commented out since I am adjusting Hoeffding to 0.25 as such I only need to generate that
  
  list(
    #b.pearson   = cor.label(trunc(cor(b_mat, method = "pearson") * 1e4) / 1e4),
    #m.pearson   = cor.label(trunc(cor(m_mat, method = "pearson") * 1e4) / 1e4),
    #spearman    = cor.label(trunc(cor(b_mat, method = "spearman") * 1e4) / 1e4),
    kendall     = cor.label(trunc(cor(b_mat, method = "kendall") * 1e4) / 1e4),
    hoeffding   = cor.label(trunc(hoeffd(b_mat)$D * 1e4) / 1e4) #,
    #b.distance  = cor.label(trunc(dcor.matrix(b_mat) * 1e4) / 1e4),
    #m.distance  = cor.label(trunc(dcor.matrix(m_mat) * 1e4) / 1e4),
    #MIC         = cor.label(trunc(as.matrix(mine(b_mat, n.cores = 8, var.thr = 1e-6)$MIC) * 1e4) / 1e4)
  )
}



# ORIGINAL
set.seed(1)
First_1000_original <- compute_all_metrics(First_1000, First_1000_M, permute = FALSE)


# 100 INDEPENDENT RESAMPLES
for (i in 1:100) {
  assign(
    paste0("First_1000_resample_", i),
    compute_all_metrics(First_1000, First_1000_M, permute = TRUE)
  )
  print(paste("Completed resample", i))
}




### This is for our original threshold, some other work is done below


# Define the threshold
threshold <- 0.75

# Create an empty list to store the dataframes for each metric
high_row_counts_list <- list()

# List of metric names you computed
metric_names <- names(First_1000_original)

# Loop over each metric
for(metric in metric_names) {
  
  # Compute row counts for the original matrix
  original_counts <- rowSums(abs(First_1000_original[[metric]]) >= threshold) - 1
  
  # Create the data frame with the original counts
  df_counts <- data.frame(Original = original_counts, stringsAsFactors = FALSE)
  
  # Add an "ID" column using rownames from the original metric matrix
  df_counts$ID <- rownames(First_1000_original[[metric]])
  
  # Loop through the 100 resamples and add each as a new column
  for(i in 1:100) {
    # Retrieve the resample object
    resample_obj <- get(paste0("First_1000_resample_", i))
    
    # Compute row counts for this resample and add as a new column
    df_counts[[paste0("Resample_", i)]] <- rowSums(abs(resample_obj[[metric]]) >= threshold) - 1
  }
  
  # Optionally, rearrange columns so that the ID column is first
  df_counts <- df_counts[, c("ID", "Original", paste0("Resample_", 1:100))]
  
  # Save the dataframe into the list with the metric name as key
  high_row_counts_list[[metric]] <- df_counts

}


# Save each dataframe in the list as a CSV file
for(metric in names(high_row_counts_list)) {
  csv_filename <- paste0("high_row_counts_", metric, ".csv")
  write.csv(high_row_counts_list[[metric]], file = csv_filename, row.names = FALSE)
}


############### 
# Section 2
############### 


# Let us make some Box plots for the Original Cutoff

library(data.table)
library(ggplot2)

# List of metric names
metrics <- names(high_row_counts_list)

for(metric in metrics) {
  # Make a copy of the data.table and ensure it's a data.table
  dt <- copy(high_row_counts_list[[metric]])
  setDT(dt)
  
  # Compute row-wise median for columns 2 to 102
  dt[, median_val := apply(.SD, 1, median), .SDcols = 2:102]
  
  # If the 'Original' column exists, order by it descending
  if("Original" %in% names(dt)) {
    setorder(dt, -Original)
  }
  
  # Create subsets for each row range with a group label
  sub1 <- dt[1:100, .(group = "Rows 1-100", Original, median_val)]
  sub2 <- dt[451:550, .(group = "Rows 451-550", Original, median_val)]
  sub3 <- dt[901:1000, .(group = "Rows 901-1000", Original, median_val)]
  
  # Combine the subsets into one data.table
  combined <- rbind(sub1, sub2, sub3)
  
  # Reshape to long format so that each row is a measurement from either "Original" or "median_val"
  long_data <- melt(combined, id.vars = "group", 
                    variable.name = "measure", value.name = "value")
  
  # Create the boxplot
  p <- ggplot(long_data, aes(x = interaction(group, measure), y = value)) +
    geom_boxplot() +
    labs(title = paste("Boxplots for", metric),
         x = "Row Range and Measurement",
         y = "Value") +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  # Save the plot to a PDF file named after the metric
  pdf_file <- paste0(metric, "_boxplot.pdf")
  pdf(pdf_file, width = 8, height = 6)
  print(p)
  dev.off()
}


############### 
# Section 3
############### 



# Define thresholds for each metric
thresholds <- list(
  hoeffding = 0.25,
  kendall   = 0.6
  #MIC       = 0.6
)

# Create an empty list to store the adjusted dataframes for each metric
high_row_counts_list_adjusted <- list()

# List of metrics to adjust
adjusted_metric_names <- c("hoeffding", "kendall")

# Loop over each metric in the adjusted set
for(metric in adjusted_metric_names) {
  
  # Get the threshold for the current metric
  current_threshold <- thresholds[[metric]]
  
  # Compute row counts for the original matrix using the adjusted threshold
  original_counts <- rowSums(abs(First_1000_original[[metric]]) >= current_threshold) - 1
  
  # Create the data frame with the original counts
  df_counts <- data.frame(Original = original_counts, stringsAsFactors = FALSE)
  
  # Add an "ID" column using rownames from the original metric matrix
  df_counts$ID <- rownames(First_1000_original[[metric]])
  
  # Loop through the 100 resamples and add each as a new column
  for(i in 1:100) {
    # Retrieve the resample object
    resample_obj <- get(paste0("First_1000_resample_", i))
    
    # Compute row counts for this resample with the adjusted threshold and add as a new column
    df_counts[[paste0("Resample_", i)]] <- rowSums(abs(resample_obj[[metric]]) >= current_threshold) - 1
  }
  
  # Optionally, rearrange columns so that the ID column is first
  df_counts <- df_counts[, c("ID", "Original", paste0("Resample_", 1:100))]
  
  # Create a name that includes the metric and the threshold value
  list_name <- paste0(metric, "_", current_threshold)
  
  # Save the dataframe into the adjusted list with the new name as the key
  high_row_counts_list_adjusted[[list_name]] <- df_counts
  
  # Save the dataframe as a CSV file, including the threshold in the filename
  csv_filename <- paste0("high_row_counts_", metric, "_", current_threshold, ".csv")
  write.csv(df_counts, file = csv_filename, row.names = FALSE)
}



# Loop over each adjusted metric in the list
metrics_adjusted <- names(high_row_counts_list_adjusted)

for(metric in metrics_adjusted) {
  # Make a copy of the data.table and ensure it's a data.table
  dt <- copy(high_row_counts_list_adjusted[[metric]])
  setDT(dt)
  
  # Compute row-wise median for columns 2 to 102
  dt[, median_val := apply(.SD, 1, median), .SDcols = 2:102]
  
  # If the 'Original' column exists, order by it descending
  if("Original" %in% names(dt)) {
    setorder(dt, -Original)
  }
  
  # Create subsets for each row range with a group label
  sub1 <- dt[1:100, .(group = "Rows 1-100", Original, median_val)]
  sub2 <- dt[451:550, .(group = "Rows 451-550", Original, median_val)]
  sub3 <- dt[901:1000, .(group = "Rows 901-1000", Original, median_val)]
  
  # Combine the subsets into one data.table
  combined <- rbind(sub1, sub2, sub3)
  
  # Reshape to long format so that each row is a measurement from either "Original" or "median_val"
  long_data <- melt(combined, id.vars = "group", 
                    variable.name = "measure", value.name = "value")
  
  # Extract metric name and threshold from the key
  # Assuming the key is in the format "metric_threshold"
  parts <- strsplit(metric, "_")[[1]]
  metric_name <- parts[1]
  threshold_value <- parts[2]
  
  # Create the boxplot, including the threshold in the title
  p <- ggplot(long_data, aes(x = interaction(group, measure), y = value)) +
    geom_boxplot() +
    labs(title = paste("Boxplots for", metric_name, "with threshold", threshold_value),
         x = "Row Range and Measurement",
         y = "Value") +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  # Save the plot to a PDF file, including the threshold in the filename
  pdf_file <- paste0(metric, "_boxplot.pdf")
  pdf(pdf_file, width = 8, height = 6)
  print(p)
  dev.off()
}


############### 
# Section 4
############### 

# "A “control” or “null” distribution via randomization (or shuffling) shows what correlation looks like if the data have no real underlying structure."
# Since the high correlations do not dissapear - the high counts are not random artifacts and instead is strong evidence that the correlation structure is meaningful



###############################################################################
#
# - Null Hypothesis (H0): The row’s (site’s) number of above-threshold correlations is due to random chance (no real underlying correlation structure).
# - Alternative Hypothesis (H1): The row’s observed count is higher than expected under a purely random (shuffled) scenario, indicating real correlation structure.
#
# Why a permutation-based approach?
# - We cannot simply do a z-test because the distribution of these "correlation counts"is not necessarily normal or may violate other assumptions of parametric tests.
# - By using `Resample_1` through `Resample_100` (each representing a random shuffle or permutation), we generate a null distribution of counts for each site. 
# - We then compare the actual (Original) count to this null distribution to obtain an empirical p-value.
###############################################################################


get_significant_rows <- function(metric_list, alpha = 0.05, save_csv = FALSE, csv_prefix = "significant_") {
  # Initialize an empty list to store significant rows for each metric
  significant_rows_list <- list()
  
  # Loop over each metric in the list (assuming the list is named)
  for(metric in names(metric_list)) {
    # Copy the data.table so we don't modify the original directly
    dt <- copy(metric_list[[metric]])
    setDT(dt)  # Ensure it's a data.table
    
    # Identify resample columns (assuming they all follow "Resample_*" naming)
    resample_cols <- grep("^Resample_", names(dt), value = TRUE)
    num_resamples <- length(resample_cols)
    
    # Compute empirical p-values:
    # p_value = (# of resamples >= Original) / total # of resamples
    dt[, p_value := rowSums(.SD >= Original) / num_resamples, .SDcols = resample_cols]
    
    # Filter for significant rows at the chosen alpha
    sig_dt <- dt[p_value < alpha]
    
    # Store the significant rows in the list
    significant_rows_list[[metric]] <- sig_dt
  
    # Print a quick summary
    cat("Metric:", metric, 
        "- Total rows:", nrow(dt), 
        "- Significant rows:", nrow(sig_dt), "\n")
  }
  
  return(significant_rows_list)
}

significant_rows_list <- get_significant_rows(high_row_counts_list, alpha = 0.05, save_csv = FALSE)
significant_rows_adjusted_list <- get_significant_rows(high_row_counts_list_adjusted, alpha = 0.05, save_csv = TRUE)

################################
################################

create_confusion_matrices <- function(metric_list, 
                                      original_col = "Original", 
                                      resample_pattern = "^Resample_",
                                      tol = 1e-8) {
  # Initialize list to store confusion matrices
  confusion_list <- list()
  
  for(metric in names(metric_list)) {
    # Copy and ensure data.table format
    dt <- copy(metric_list[[metric]])
    setDT(dt)
    
    # Identify resample columns (using a naming pattern, e.g., "Resample_*")
    resample_cols <- grep(resample_pattern, names(dt), value = TRUE)
    num_resamples <- length(resample_cols)
    
    # Compute empirical p-values:
    # p_value = (# of resample values >= Original) / number of resamples
    dt[, p_value := rowSums(.SD >= get(original_col)) / num_resamples, .SDcols = resample_cols]
    
    # Bucket the original values:
    # >=10, between 0 and <10, and 0
    dt[, original_bucket := ifelse(get(original_col) >= 10, ">=10",
                                   ifelse(get(original_col) > 0 & get(original_col) < 10, "10>x>0", "0"))]
    
    # Bucket the p-values:
    # p_value == 1, p_value == 0, and between 0 and 1
    dt[, p_bucket := ifelse(p_value == 1, "1",
                            ifelse(p_value == 0, "0", "1>x>0"))]
    
    # Enforce the ordering of levels so that the confusion matrix
    # has rows and columns in the desired order.
    original_levels <- c(">=10", "10>x>0", "0")
    p_levels <- c("1", "1>x>0", "0")
    
    dt[, original_bucket := factor(original_bucket, levels = original_levels)]
    dt[, p_bucket := factor(p_bucket, levels = p_levels)]
    
    # Create a 3x3 confusion matrix (table)
    confusion <- table(dt$original_bucket, dt$p_bucket)
    
    # Save the confusion matrix to the list
    confusion_list[[metric]] <- confusion
  }
  
  return(confusion_list)
}

confusion_matrices <- create_confusion_matrices(high_row_counts_list)
confusion_matrices_adjusted <- create_confusion_matrices(high_row_counts_list_adjusted)

# Save confusion matrices for the original list
for (metric in names(confusion_matrices)) {
  confusion_df <- as.data.frame.matrix(confusion_matrices[[metric]])
  write.csv(confusion_df, file = paste0("confusion_", metric, ".csv"), row.names = TRUE)
}

# Save confusion matrices for the adjusted list
for (metric in names(confusion_matrices_adjusted)) {
  confusion_df <- as.data.frame.matrix(confusion_matrices_adjusted[[metric]])
  write.csv(confusion_df, file = paste0("confusion_adjusted_", metric, ".csv"), row.names = TRUE)
}


all_data = read.table(file = "BRCA.53Alive.Normal.380355cg.75col.Aug18.2022.txt", header = TRUE ) # The Original Big Data




create_confusion_matrix_by_variance_custom <- function(metric_list, row_vars, 
                                                       original_col = "Original", 
                                                       p_resample_pattern = "^Resample_") {
  # Initialize a list to store confusion matrices
  confusion_list <- list()
  
  # Loop over each metric in the list (assuming the list is named)
  for(metric in names(metric_list)) {
    # Copy and convert to data.table
    dt <- copy(metric_list[[metric]])
    setDT(dt)
    
    # Assume that the rows of dt correspond to the first n rows of all_data
    n <- nrow(dt)
    dt[, row_var := row_vars[1:n]]
    
    # Compute standard deviation from row variance
    dt[, row_std := sqrt(row_var)]
    
    # Bucket row standard deviations:
    # "Low" if < 0.1, "High" if > 0.5, and "Between" for the rest.
    dt[, var_bucket := ifelse(row_std < 0.05, "Low",
                              ifelse(row_std > 0.1, "High", "Between"))]
    
    # Identify resample columns (columns with names starting with p_resample_pattern)
    resample_cols <- grep(p_resample_pattern, names(dt), value = TRUE)
    num_resamples <- length(resample_cols)
    
    # Compute empirical p-values: (# of resample values >= Original) / total # of resamples
    if (!(original_col %in% names(dt))) {
      stop(paste("Column", original_col, "not found in metric", metric))
    }
    dt[, p_value := rowSums(.SD >= get(original_col)) / num_resamples, .SDcols = resample_cols]
    
    # Bucket the p-values:
    dt[, p_bucket := ifelse(p_value == 1, "1",
                            ifelse(p_value == 0, "0", "1>x>0"))]
    
    # Order the factors
    dt[, var_bucket := factor(var_bucket, levels = c("Low", "Between", "High"))]
    dt[, p_bucket := factor(p_bucket, levels = c("1", "1>x>0", "0"))]
    
    # Create a confusion matrix (table) for var_bucket (rows) vs. p_bucket (columns)
    confusion <- table(dt$var_bucket, dt$p_bucket)
    confusion_list[[metric]] <- confusion
  }
  
  return(confusion_list)
}


row_vars_all <- apply(all_data[, 5:34], 1, var)
row_vars_subset <- row_vars_all[1:1000]

test = sqrt(row_vars_subset)
summary(test)

# For the original metric list:
confusion_by_variance_custom <- create_confusion_matrix_by_variance_custom(high_row_counts_list, row_vars_subset)

# For the adjusted metric list:
confusion_by_variance_custom_adjusted <- create_confusion_matrix_by_variance_custom(high_row_counts_list_adjusted, row_vars_subset)

# To save each confusion matrix as a CSV:
for (metric in names(confusion_by_variance_custom)) {
  confusion_df <- as.data.frame.matrix(confusion_by_variance_custom[[metric]])
  write.csv(confusion_df, file = paste0("confusion_variance_custom_", metric, ".csv"), row.names = TRUE)
}

for (metric in names(confusion_by_variance_custom_adjusted)) {
  confusion_df <- as.data.frame.matrix(confusion_by_variance_custom_adjusted[[metric]])
  write.csv(confusion_df, file = paste0("confusion_variance_custom_adjusted_", metric, ".csv"), row.names = TRUE)
}



############### 
# Section 5
############### 
create_summary_table <- function(metric_list, resample_cols = 3:102, original_col = "Original") {
  
  # Initialize an empty list to store summary rows
  summary_list <- list()
  
  # Loop over each metric in the list (assuming the list is named)
  for (metric in names(metric_list)) {
    
    # Convert to a data.table
    dt <- as.data.table(metric_list[[metric]])
    
    # Check that the 'Original' column exists
    if (!(original_col %in% names(dt))) {
      cat("Metric", metric, "does not have the", original_col, "column.\n")
      next
    }
    
    # Compute the 6-number summary for the Original column
    original_summary <- c(
      Min    = min(dt[[original_col]], na.rm = TRUE),
      Q1     = quantile(dt[[original_col]], 0.25, na.rm = TRUE),
      Median = median(dt[[original_col]], na.rm = TRUE),
      Mean   = mean(dt[[original_col]], na.rm = TRUE),
      Q3     = quantile(dt[[original_col]], 0.75, na.rm = TRUE),
      Max    = max(dt[[original_col]], na.rm = TRUE)
    )
    
    # Combine the resample columns (columns specified in resample_cols)
    resample_values <- unlist(dt[, resample_cols, with = FALSE])
    resample_summary <- c(
      Min    = min(resample_values, na.rm = TRUE),
      Q1     = quantile(resample_values, 0.25, na.rm = TRUE),
      Median = median(resample_values, na.rm = TRUE),
      Mean   = mean(resample_values, na.rm = TRUE),
      Q3     = quantile(resample_values, 0.75, na.rm = TRUE),
      Max    = max(resample_values, na.rm = TRUE)
    )
    
    # Create data frames for each summary type (Original and Resamples)
    original_df <- data.frame(Metric = metric,
                              Type = "Original",
                              t(original_summary),
                              row.names = NULL)
    
    resamples_df <- data.frame(Metric = metric,
                               Type = "Resamples",
                               t(resample_summary),
                               row.names = NULL)
    
    # Append the two data frames to the list
    summary_list[[length(summary_list) + 1]] <- original_df
    summary_list[[length(summary_list) + 1]] <- resamples_df
  }
  
  # Combine all the summary rows into one table
  summary_table <- do.call(rbind, summary_list)
  return(summary_table)
}


# Example usage:
# For your original list:
summary_table_original <- create_summary_table(high_row_counts_list)

# For your adjusted list:
summary_table_adjusted <- create_summary_table(high_row_counts_list_adjusted)

# View the resulting tables
print(summary_table_original)
print(summary_table_adjusted)

# Write the original summary table as CSV
write.csv(summary_table_original, "summary_table_original.csv", row.names = FALSE)

# Write the adjusted summary table as CSV
write.csv(summary_table_adjusted, "summary_table_adjusted.csv", row.names = FALSE)


####################
####################
####################





