#!/bin/bash

module load R


############## YELLOW ###############
# b.pear.10 x b.pear.30
R CMD BATCH '--args b.pear.10 2022-09-30 b.pear.30 2022-09-30' make.table.from.txt.2022-10-16.R b.pear.10.x.b.pear.30.2022-10-16.Rout
# b.pear.10 x b.pear.53
R CMD BATCH '--args b.pear.10 2022-09-30 b.pear.53 2022-09-30' make.table.from.txt.2022-10-16.R b.pear.10.x.b.pear.53.2022-10-16.Rout
# b.pear.30 x b.pear.53
R CMD BATCH '--args b.pear.30 2022-09-30 b.pear.53 2022-09-30' make.table.from.txt.2022-10-16.R b.pear.30.x.b.pear.53.2022-10-16.Rout

# m.pear.10 x m.pear.30
R CMD BATCH '--args m.pear.10 2022-09-30 m.pear.30 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.10.x.m.pear.30.2022-10-16.Rout
# m.pear.10 x m.pear.53
R CMD BATCH '--args m.pear.10 2022-09-30 m.pear.53 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.10.x.m.pear.53.2022-10-16.Rout
# m.pear.30 x m.pear.53
R CMD BATCH '--args m.pear.30 2022-09-30 m.pear.53 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.30.x.m.pear.53.2022-10-16.Rout

# spear.10 x spear.30
R CMD BATCH '--args spear.10 2022-09-30 spear.30 2022-09-30' make.table.from.txt.2022-10-16.R spear.10.x.spear.30.2022-10-16.Rout
# spear.10 x spear.53
R CMD BATCH '--args spear.10 2022-09-30 spear.53 2022-09-30' make.table.from.txt.2022-10-16.R spear.10.x.spear.53.2022-10-16.Rout
# spear.30 x spear.53
R CMD BATCH '--args spear.30 2022-09-30 spear.53 2022-09-30' make.table.from.txt.2022-10-16.R spear.30.x.spear.53.2022-10-16.Rout

# kend.10 x kend.30
R CMD BATCH '--args kend.10 2022-09-30 kend.30 2022-09-30' make.table.from.txt.2022-10-16.R kend.10.x.kend.30.2022-10-16.Rout
# kend.10 x kend.53
R CMD BATCH '--args kend.10 2022-09-30 kend.53 2022-09-30' make.table.from.txt.2022-10-16.R kend.10.x.kend.53.2022-10-16.Rout
# kend.30 x kend.53
R CMD BATCH '--args kend.30 2022-09-30 kend.53 2022-09-30' make.table.from.txt.2022-10-16.R kend.30.x.kend.53.2022-10-16.Rout

# hoef.10 x hoef.30
R CMD BATCH '--args hoef.10 2022-09-30 hoef.30 2022-09-30' make.table.from.txt.2022-10-16.R hoef.10.x.hoef.30.2022-10-16.Rout
# hoef.10 x hoef.53
R CMD BATCH '--args hoef.10 2022-09-30 hoef.53 2022-09-30' make.table.from.txt.2022-10-16.R hoef.10.x.hoef.53.2022-10-16.Rout
# hoef.30 x hoef.53
R CMD BATCH '--args hoef.30 2022-09-30 hoef.53 2022-09-30' make.table.from.txt.2022-10-16.R hoef.30.x.hoef.53.2022-10-16.Rout

# b.dist.10 x b.dist.30
R CMD BATCH '--args b.dist.10 2022-10-01 b.dist.30 2022-10-01' make.table.from.txt.2022-10-16.R b.dist.10.x.b.dist.30.2022-10-16.Rout
# b.dist.10 x b.dist.53
R CMD BATCH '--args b.dist.10 2022-10-01 b.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R b.dist.10.x.b.dist.53.2022-10-16.Rout
# b.dist.30 x b.dist.53
R CMD BATCH '--args b.dist.30 2022-10-01 b.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R b.dist.30.x.b.dist.53.2022-10-16.Rout


# m.dist.10 x m.dist.30
R CMD BATCH '--args m.dist.10 2022-10-01 m.dist.30 2022-10-01' make.table.from.txt.2022-10-16.R m.dist.10.x.m.dist.30.2022-10-16.Rout
# m.dist.10 x m.dist.53
R CMD BATCH '--args m.dist.10 2022-10-01 m.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R m.dist.10.x.m.dist.53.2022-10-16.Rout
# m.dist.30 x m.dist.53
R CMD BATCH '--args m.dist.30 2022-10-01 m.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R m.dist.30.x.m.dist.53.2022-10-16.Rout

# mic.10 x mic.30
R CMD BATCH '--args mic.10 2022-09-30 mic.30 2022-09-30' make.table.from.txt.2022-10-16.R mic.10.x.mic.30.2022-10-16.Rout
# mic.10 x mic.53
R CMD BATCH '--args mic.10 2022-09-30 mic.53 2022-09-30' make.table.from.txt.2022-10-16.R mic.10.x.mic.53.2022-10-16.Rout
# mic.30 x mic.53
R CMD BATCH '--args mic.30 2022-09-30 mic.53 2022-09-30' make.table.from.txt.2022-10-16.R mic.30.x.mic.53.2022-10-16.Rout

########### PURPLE ##############
# b.pear.10 x m.pear.10
R CMD BATCH '--args b.pear.10 2022-09-30 m.pear.10 2022-09-30' make.table.from.txt.2022-10-16.R b.pear.10.x.m.pear.10.2022-10-16.Rout
# b.pear.30 x m.pear.30
R CMD BATCH '--args b.pear.30 2022-09-30 m.pear.30 2022-09-30' make.table.from.txt.2022-10-16.R b.pear.30.x.m.pear.30.2022-10-16.Rout
# b.pear.53 x m.pear.53
R CMD BATCH '--args b.pear.53 2022-09-30 m.pear.53 2022-09-30' make.table.from.txt.2022-10-16.R b.pear.53.x.m.pear.53.2022-10-16.Rout

# b.dist.10 x m.dist.10
R CMD BATCH '--args b.dist.10 2022-10-01 m.dist.10 2022-10-01' make.table.from.txt.2022-10-16.R b.dist.10.x.m.dist.10.2022-10-16.Rout
# b.dist.30 x m.dist.30
R CMD BATCH '--args b.dist.30 2022-10-01 m.dist.30 2022-10-01' make.table.from.txt.2022-10-16.R b.dist.30.x.m.dist.30.2022-10-16.Rout
# b.dist.53 x m.dist.53
R CMD BATCH '--args b.dist.53 2022-10-01 m.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R b.dist.53.x.m.dist.53.2022-10-16.Rout

########## BLUE ###############
# m.pear.10 x spear.10
R CMD BATCH '--args m.pear.10 2022-09-30 spear.10 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.10.x.spear.10.2022-10-16.Rout
# m.pear.30 x spear.30
R CMD BATCH '--args m.pear.30 2022-09-30 spear.30 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.30.x.spear.30.2022-10-16.Rout
# m.pear.53 x spear.53
R CMD BATCH '--args m.pear.53 2022-09-30 spear.53 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.53.x.spear.53.2022-10-16.Rout

# m.pear.10 x kend.10
R CMD BATCH '--args m.pear.10 2022-09-30 kend.10 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.10.x.kend.10.2022-10-16.Rout
# m.pear.30 x kend.30
R CMD BATCH '--args m.pear.30 2022-09-30 kend.30 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.30.x.kend.30.2022-10-16.Rout
# m.pear.53 x kend.53
R CMD BATCH '--args m.pear.53 2022-09-30 kend.53 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.53.x.kend.53.2022-10-16.Rout

# m.pear.10 x hoef.10
R CMD BATCH '--args m.pear.10 2022-09-30 hoef.10 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.10.x.hoef.10.2022-10-16.Rout
# m.pear.30 x hoef.30
R CMD BATCH '--args m.pear.30 2022-09-30 hoef.30 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.30.x.hoef.30.2022-10-16.Rout
# m.pear.53 x hoef.53
R CMD BATCH '--args m.pear.53 2022-09-30 hoef.53 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.53.x.hoef.53.2022-10-16.Rout

# m.pear.10 x b.dist.10
R CMD BATCH '--args m.pear.10 2022-09-30 b.dist.10 2022-10-01' make.table.from.txt.2022-10-16.R m.pear.10.x.b.dist.10.2022-10-16.Rout
# m.pear.30 x b.dist.30
R CMD BATCH '--args m.pear.30 2022-09-30 b.dist.30 2022-10-01' make.table.from.txt.2022-10-16.R m.pear.30.x.b.dist.30.2022-10-16.Rout
# m.pear.53 x b.dist.53
R CMD BATCH '--args m.pear.53 2022-09-30 b.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R m.pear.53.x.b.dist.53.2022-10-16.Rout

# m.pear.10 x m.dist.10
R CMD BATCH '--args m.pear.10 2022-09-30 m.dist.10 2022-10-01' make.table.from.txt.2022-10-16.R m.pear.10.x.m.dist.10.2022-10-16.Rout
# m.pear.30 x m.dist.30
R CMD BATCH '--args m.pear.30 2022-09-30 m.dist.30 2022-10-01' make.table.from.txt.2022-10-16.R m.pear.30.x.m.dist.30.2022-10-16.Rout
# m.pear.53 x m.dist.53
R CMD BATCH '--args m.pear.53 2022-09-30 m.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R m.pear.53.x.m.dist.53.2022-10-16.Rout

# m.pear.10 x mic.10
R CMD BATCH '--args m.pear.10 2022-09-30 mic.10 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.10.x.mic.10.2022-10-16.Rout
# m.pear.30 x mic.30
R CMD BATCH '--args m.pear.30 2022-09-30 mic.30 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.30.x.mic.30.2022-10-16.Rout
# m.pear.53 x mic.53
R CMD BATCH '--args m.pear.53 2022-09-30 mic.53 2022-09-30' make.table.from.txt.2022-10-16.R m.pear.53.x.mic.53.2022-10-16.Rout

######### GREEN ##############
# b.pear.10 x b.dist.10
R CMD BATCH '--args b.pear.10 2022-09-30 b.dist.10 2022-10-01' make.table.from.txt.2022-10-16.R b.pear.10.x.b.dist.10.2022-10-16.Rout
# b.pear.30 x b.dist.30
R CMD BATCH '--args b.pear.30 2022-09-30 b.dist.30 2022-10-01' make.table.from.txt.2022-10-16.R b.pear.30.x.b.dist.30.2022-10-16.Rout
# b.pear.53 x b.dist.53
R CMD BATCH '--args b.pear.53 2022-09-30 b.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R b.pear.53.x.b.dist.53.2022-10-16.Rout

# spear.10 x m.dist.10
R CMD BATCH '--args spear.10 2022-09-30 m.dist.10 2022-10-01' make.table.from.txt.2022-10-16.R spear.10.x.m.dist.10.2022-10-16.Rout
# spear.30 x m.dist.30
R CMD BATCH '--args spear.30 2022-09-30 m.dist.30 2022-10-01' make.table.from.txt.2022-10-16.R spear.30.x.m.dist.30.2022-10-16.Rout
# spear.53 x m.dist.53
R CMD BATCH '--args spear.53 2022-09-30 m.dist.53 2022-10-01' make.table.from.txt.2022-10-16.R spear.53.x.m.dist.53.2022-10-16.Rout

# kend.10 x hoef.10
R CMD BATCH '--args kend.10 2022-09-30 hoef.10 2022-09-30' make.table.from.txt.2022-10-16.R kend.10.x.hoef.10.2022-10-16.Rout
# kend.30 x hoef.30
R CMD BATCH '--args kend.30 2022-09-30 hoef.30 2022-09-30' make.table.from.txt.2022-10-16.R kend.30.x.hoef.30.2022-10-16.Rout
# kend.53 x hoef.53
R CMD BATCH '--args kend.53 2022-09-30 hoef.53 2022-09-30' make.table.from.txt.2022-10-16.R kend.53.x.hoef.53.2022-10-16.Rout

# hoef.10 x mic.10
R CMD BATCH '--args hoef.10 2022-09-30 mic.10 2022-09-30' make.table.from.txt.2022-10-16.R hoef.10.x.mic.10.2022-10-16.Rout
# hoef.30 x mic.30
R CMD BATCH '--args hoef.30 2022-09-30 mic.30 2022-09-30' make.table.from.txt.2022-10-16.R hoef.30.x.mic.30.2022-10-16.Rout
# hoef.53 x mic.53
R CMD BATCH '--args hoef.53 2022-09-30 mic.53 2022-09-30' make.table.from.txt.2022-10-16.R hoef.53.x.mic.53.2022-10-16.Rout

# m.dist.10 x mic.10
R CMD BATCH '--args m.dist.10 2022-10-01 mic.10 2022-09-30' make.table.from.txt.2022-10-16.R  m.dist.10.x.mic.10.2022-10-16.Rout
# m.dist.30 x mic.30
R CMD BATCH '--args m.dist.30 2022-10-01 mic.30 2022-09-30' make.table.from.txt.2022-10-16.R  m.dist.30.x.mic.30.2022-10-16.Rout
# m.dist.53 x mic.53
R CMD BATCH '--args m.dist.53 2022-10-01 mic.53 2022-09-30' make.table.from.txt.2022-10-16.R  m.dist.53.x.mic.53.2022-10-16.Rout













