corrs.in.intv <- function(interval, vect) {
  -sign((vect - interval[1])*(vect-interval[2]+10^(-7))) # returns vector with each element in the list of correlations, valued 1 if within the interval and -1 if not within the interval
}

intvs.of.corrs <- function(intervals, vect) {
  sign(sapply(intervals, corrs.in.intv, vect)+1) # returns matrix with len(intervals) columns and len(vect) rows, each row has exactly one 1 corresponding to the correct interval for that vector element
}

upperTriVect <- function(mat) { # converts matrix into a list of upper triangle correlations
  unlist(mat[upper.tri(mat)]) # by default does not include diagonal
}

IntervalOverlapTable <- function(mat1, mat2, intervals,intv.labels1,intv.labels2) {
  mat1.intvs <- intvs.of.corrs(intervals,upperTriVect(mat1)) # returns matrices denoting the interval each correlation falls within
  mat2.intvs <- intvs.of.corrs(intervals,upperTriVect(mat2)) 
  rawcounts = t(mat1.intvs) %*% mat2.intvs # matrix multiplication: intervalxcorrelations * correlationsxinterval => intervalxinterval where each correlation gets summed into the cell corresponding to the two intervals it fell within
                                  # if corr was in 3rd interval for mat1, 5th interval for mat2, would tally with mat1.ints[3,:] %*% mat2.ints[:,5] and will add into cell [3,5] of the rawcounts matrix
  rowcounts = matrix(colSums(mat1.intvs),nrow=length(intervals), ncol=length(intervals)) # column vector of row sums for mat1, copied over into as many columns as their are intervals
  rawcounts[] = paste(trunc(100000*rawcounts/rowcounts)/1000,"%  ",rawcounts,sep="")
  rawcounts=as.data.frame(rawcounts)
  #rawcounts[] <- paste(trunc(1000*rawcounts/rowcounts)/10, "% ", rawcounts, "/", rowcounts, sep = "")
  rownames(rawcounts)=intv.labels1
  colnames(rawcounts)=intv.labels2
  #cat(dim(rawcounts))
  #cat(dim(colSums(mat1.intvs)))
  rawcounts['Total Count']<- colSums(mat1.intvs)
  #cat(typeof(rawcounts))
  noquote(rawcounts)
}
