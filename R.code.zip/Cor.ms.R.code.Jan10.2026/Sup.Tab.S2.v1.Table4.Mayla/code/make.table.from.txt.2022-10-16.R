source("IntervalOverlapTable.2022-09-22.R")

args <- commandArgs(TRUE)

corr1=args[1]
date1=args[2]
corr2=args[3]
date2=args[4]

system.time(corr.mat1 <- read.table(paste("/home/nxo9/BRCAResearch/correlations/txt.tables/",corr1,".mayla.",date1,".txt",sep=""),header=T))
system.time(corr.mat2 <- read.table(paste("/home/nxo9/BRCAResearch/correlations/txt.tables/",corr2,".mayla.",date2,".txt",sep=""),header=T))

intervals = list(c(-1, -0.75), c(-0.75, -0.5), c(-0.5, -0.25), c(-0.25, 0), c(0,0.25), c(0.25,0.5), c(0.5, 0.75), c(0.75, 1.01))
intv.labels1=c(paste(corr1,"[-1,-0.75)"),paste(corr1,"[-0.75,-0.5)"),paste(corr1,"[-0.5,-0.25)"),paste(corr1,"[-0.25,0)"),paste(corr1,"[0,0.25)"),paste(corr1,"[0.25,0.5)"),paste(corr1,"[0.5,0.75)"),paste(corr1,"[0.75,1]"))
intv.labels2=c(paste(corr2,"[-1,-0.75)"),paste(corr2,"[-0.75,-0.5)"),paste(corr2,"[-0.5,-0.25)"),paste(corr2,"[-0.25,0)"),paste(corr2,"[0,0.25)"),paste(corr2,"[0.25,0.5)"),paste(corr2,"[0.5,0.75)"),paste(corr2,"[0.75,1]"))

system.time(output <- IntervalOverlapTable(corr.mat1,corr.mat2,intervals,intv.labels1,intv.labels2))

system.time(write.table(output,file=paste("/home/nxo9/BRCAResearch/eight.x.eight/",corr1,".and.",corr2,".eight.x.eight.",format(Sys.Date(), "%Y-%m-%d"),".csv",sep=""),sep=","))
