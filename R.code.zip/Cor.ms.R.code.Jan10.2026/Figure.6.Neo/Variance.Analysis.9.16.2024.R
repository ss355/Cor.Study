# 2/5/2024
# Updating Graphs

# Fixing the following:
# [Note 106 SS.Review/7.Jan11.2024.Review.60p.pdf, may remove Figure R12 later, or may regenerate with a single graph showing both parts next to each other]
# [Note 112 SS.Review/7.Jan11.2024.Review.60p.pdf: regenerate Figure R13 with title and legend larger, shorten titles of each subplot. Also, re-order subplots to be ‘Random’, ‘Less than’, ‘Between’, and ‘Greater than’ (from left -> right, top -> bottom)]
# First 10000 Sites

library(matrixStats)

normal.all.BRCA.variance.analysis.30N = data.frame(normal.all.BRCA[1:10000,1],normal.all.BRCA[1:10000,5:34])
variances = rowVars(as.matrix(normal.all.BRCA.variance.analysis.30N[,2:31]))
std = sqrt(variances)
maxs = rowMaxs(as.matrix(normal.all.BRCA.variance.analysis.30N[,2:31]))
mins = rowMins(as.matrix(normal.all.BRCA.variance.analysis.30N[,2:31]))
max.min.diff = maxs - mins

normal.all.BRCA.variance.analysis.30N = cbind(normal.all.BRCA.variance.analysis.30N,std,maxs,mins,max.min.diff)



# Whole Data Frame
normal.all.BRCA.variance.analysis.30N.all = data.frame(normal.all.BRCA[,1],normal.all.BRCA[,5:34])
variances.all = rowVars(as.matrix(normal.all.BRCA.variance.analysis.30N.all[,2:31]))
std.all = sqrt(variances.all)
maxs.all = rowMaxs(as.matrix(normal.all.BRCA.variance.analysis.30N.all[,2:31]))
mins.all = rowMins(as.matrix(normal.all.BRCA.variance.analysis.30N.all[,2:31]))
max.min.diff.all = maxs.all - mins.all

normal.all.BRCA.variance.analysis.30N.all = cbind(normal.all.BRCA.variance.analysis.30N.all,std.all,maxs.all,mins.all,max.min.diff.all)


# Histogram for STD
pdf(file = paste("Histograms.Of.The.Standard.Deviations", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width=16, height=8, onefile = TRUE)
par(mfrow=c(1,2))

hist(normal.all.BRCA.variance.analysis.30N$std, xlab = "Standard Deviation", main = "Histogram Showing The Frequencies For Standard Deviations For The First 10000 Sites", breaks = "Scott", col = 4)
hist(normal.all.BRCA.variance.analysis.30N.all$std.all, xlab = "Standard Deviation", main = "Histogram Showing The Frequencies For Standard Deviation Of The Entire Data Frame" , breaks = "Scott", col = 4)

dev.off()



# Histograms for Max-Min Diff
pdf(file = paste("Histograms.Of.The.Max.Min.Diffs", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width=16, height=8, onefile = TRUE)
par(mfrow=c(1,2))

hist(normal.all.BRCA.variance.analysis.30N$max.min.diff, xlab = "Difference Between Max and Min", xlim = c(0,1), col = 2, breaks = "Scott", main = "Histogram Showing the Max-Min Differences For The First 10000 Sites")
hist(normal.all.BRCA.variance.analysis.30N.all$max.min.diff.all, xlab = "Difference Between Max and Min", xlim = c(0,1), breaks = "Scott", main = "Histogram Showing the Max-Min Differences Of The Entire Data Frame", col = 2)

dev.off()


#####################################

Subset.of.std.higher.than.0.1 = normal.all.BRCA.variance.analysis.30N[which (normal.all.BRCA.variance.analysis.30N$std > 0.1),]

Subset.of.std.between = normal.all.BRCA.variance.analysis.30N[which (normal.all.BRCA.variance.analysis.30N$std <= 0.1 & normal.all.BRCA.variance.analysis.30N$std >= 0.05),]

Subset.of.std.lower.than.0.05 = normal.all.BRCA.variance.analysis.30N[which (normal.all.BRCA.variance.analysis.30N$std < 0.05),]

sampleindex = sample(1:10000, 1000, replace=FALSE)
Random.1000.of.the.10k.variance = normal.all.BRCA.variance.analysis.30N[sampleindex,]


First.1000.of.the.std.higher.than.0.1 = Subset.of.std.higher.than.0.1[1:1000,]
First.1000.of.the.std.between = Subset.of.std.between[1:1000,]
First.1000.of.the.std.less.than.0.05 = Subset.of.std.lower.than.0.05[1:1000,]


# Random
sampleindex2 = sample(1:4894, 1000, replace=FALSE)
Random.1000.of.the.10k.variance2 = normal.all.BRCA.variance.analysis.30N[sampleindex2,]


#####################################

# List Needed for Function
sample30N.list = list(B.pearson.10kx10k.30N,M.pearson.10kx10k.30N,Spearman.10kx10k.30N,Kendall.10kx10k.30N,Hoeffding.10kx10k.30N,B.distance.10kx10k.30N,M.distance.10kx10k.30N,MIC.10kx10k.30N)
names(sample30N.list) = c("B.pearson","M.pearson","Spearman","Kendall","Hoeffding","B.distance","M.distance","MIC")


Density.plotter.for.variance.subsets = function(list,df,title){
  
  temp.matrix = matrix(data = NA, nrow(df),0) # Empty matrix which will cbind later
  names = names(list) # Needed for the legend of the graph
  
  colforlegend = c(seq.int(1,length(list),1)) # Colors for the graphs
  
  graphtitle = gsub("\\.", " ", title) 
  
  for (m in 1:length(list)){
    include_list = df[,1] # Lists names of the CG sites that meet the conditions of the subset
    metric = list[[m]]
    cor_scores = metric[include_list,include_list]  # Shrinking the matrix to the sites that meet the criteria
    high_count = rowSums(abs(cor_scores) >= 0.8)    # Counting the high counts
    temp.matrix = cbind(temp.matrix,high_count)     
    
  }
  
  plot(density(temp.matrix[,1]/10), lwd = 2, main =graphtitle, xlim = c(0,100), ylim = c(0,0.40), cex.main = 2)
  for(i in 2:length(list)){
    lines(density(temp.matrix[,i]/10), col = i, lwd = 2, xlim = c(0,100), ylim = c(0,0.40))
  }
  
  legend("topright",legend = names, col = colforlegend , lwd = 2, cex = 1.4, bty = "n")
  
}


pdf(file = paste("Comparison.of.different.subsets.of.variances.div10.", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width=16, height=12, onefile = TRUE)
par(mfrow=c(2,2), cex.axis = 1.5, cex.lab = 1.5)
 
Density.plotter.for.variance.subsets(sample30N.list,Random.1000.of.the.10k.variance, "Random 1000 Sites")
Density.plotter.for.variance.subsets(sample30N.list,First.1000.of.the.std.less.than.0.05, "STD < 0_05")
Density.plotter.for.variance.subsets(sample30N.list,First.1000.of.the.std.between, "STD 0_05 and 0_1")
Density.plotter.for.variance.subsets(sample30N.list,First.1000.of.the.std.higher.than.0.1, "STD > 0_1")

dev.off()

####################################
# 3/13/2024 
# We are making bar plots for the graphs
####################################


Bar.Plotter.for.outlier.subsets = function(list,df,title){
  
  temp.matrix = matrix(data = NA, nrow(df),0) # Empty matrix which will cbind later
  names = names(list) # Needed for the legend of the graph
  
  colforlegend = c(seq.int(1,length(list),1)) # Colors for the graphs

  for (m in 1:length(list)){
    include_list = df[,1] # Lists names of the CG sites that meet the conditions of the subset
    metric = list[[m]]
    cor_scores = metric[include_list,include_list]  # Shrinking the matrix to the sites that meet the criteria
    high_count = rowSums(abs(cor_scores) >= 0.75)    # Counting the high counts
    temp.matrix = cbind(temp.matrix,high_count)     
    
  }
  
  new.temp.matrix  = matrix(data = NA, nrow = 8, ncol = 10 ,0)
  for (m in 1:length(list)){
    new.temp.vector = table(cut(temp.matrix[,m], breaks = seq(0, 1000, by = 100)))
    new.temp.matrix = rbind(new.temp.matrix,new.temp.vector)
    
  }
  
  
  barplot(new.temp.matrix ,beside = T, col = colforlegend, main = title , ylim = c(0,1000), ylab= "Frequency", xlab = "Ranges",
          cex.main = 1.7, cex.names = 0.8, cex.lab = 1.2)
  
  
  legend("top",legend = names, col = colforlegend , lwd = 2, cex = 1.4, ncol = 2)
  
}



pdf(file = paste("Comparison.of.different.subsets.of.the.std.Bar.Plots.", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width=16, height=12, onefile = TRUE)
par(mfrow=c(2,2), cex.axis = 1.5, cex.lab = 1.5)

Bar.Plotter.for.outlier.subsets(sample30N.list,Random.1000.of.the.10k.variance, "A. Random 1000 Sites")
Bar.Plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.std.less.than.0.05, "B. STD  < 0.05")
Bar.Plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.std.between, "C. STD between 0.05 and 0.1")
Bar.Plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.std.higher.than.0.1, "D. STD > 0.1")

dev.off()


