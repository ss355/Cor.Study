# copied from the summer: /home/nxo9/TumorData/code/2022-08-01.code/corrmatrix.2022-07-13.R

setwd("/home/nxo9/BRCAResearch/correlations/txt.tables/")

args <- commandArgs(TRUE)
sample_size = args[1]
metric = args[2]
corr.abs = args[3]
tenk = args[4]  #variable I set to load 10k or 1k correlation matrics

# parse information from file tail (args[1])
# file.tail = unlist(strsplit(args[1],"\\."))
# sample.type = file.tail[1]
# sites.size = file.tail[2]
# num.samples = file.tail[3]

# function for calculating across-matrix correlation for two correlation matrices
corrmat <- function(mat1,mat2,abs,corr.method){
if(sum(rownames(mat1)!=rownames(mat2))==0 && sum(colnames(mat1)!=colnames(mat2))==0){

        if(abs=="T"){
        mat1=abs(mat1)
        mat2=abs(mat2)
        }

        mat1 = mat1[upper.tri(mat1,diag=F)]
        mat2 = mat2[upper.tri(mat2,diag=F)]
        v1=unlist(c(mat1))
        v2=unlist(c(mat2))

        cors = cor(v1,v2,method=corr.method)

        return(cors)
}
}



# load in correlation matrices (10k)
if(tenk){
	m.pear = as.matrix(read.table(file = paste("m.pear.",sample_size, ".mayla.2022-09-30.txt",sep=""), header=T))
	spear = as.matrix(read.table(file = paste("spear.",sample_size,".mayla.2022-09-30.txt",sep=""), header=T))
	kend = as.matrix(read.table(file = paste("kend.",sample_size,".mayla.2022-09-30.txt",sep=""), header=T))
	mic = as.matrix(read.table(file = paste("mic.",sample_size,".mayla.2022-09-30.txt",sep=""), header=T))
	hoef = as.matrix(read.table(file = paste("hoef.",sample_size,".mayla.2022-09-30.txt",sep=""), header=T))
	m.dist = as.matrix(read.table(file = paste("m.dist.",sample_size,".mayla.2022-10-01.txt",sep=""), header=T))
	b.pear = as.matrix(read.table(file = paste("b.pear.",sample_size,".mayla.2022-09-30.txt",sep=""), header=T))
	b.dist = as.matrix(read.table(file = paste("b.dist.",sample_size,".mayla.2022-10-01.txt",sep=""), header=T))
} else { # load in 1k correlation matrices
	m.pear = as.matrix(read.table(file = paste("m.pear.1k.",sample_size, ".mayla.2023-01-17.txt",sep=""), header=T))
        spear = as.matrix(read.table(file = paste("spear.1k.",sample_size,".mayla.2023-01-17.txt",sep=""), header=T))
        kend = as.matrix(read.table(file = paste("kend.1k.",sample_size,".mayla.2023-01-17.txt",sep=""), header=T))
        mic = as.matrix(read.table(file = paste("mic.1k.",sample_size,".mayla.2023-01-17.txt",sep=""), header=T))
        hoef = as.matrix(read.table(file = paste("hoef.1k.",sample_size,".mayla.2023-01-17.txt",sep=""), header=T))
        m.dist = as.matrix(read.table(file = paste("m.dist.1k.",sample_size,".mayla.2023-01-17.txt",sep=""), header=T))
        b.pear = as.matrix(read.table(file = paste("b.pear.1k.",sample_size,".mayla.2023-01-17.txt",sep=""), header=T))
        b.dist = as.matrix(read.table(file = paste("b.dist.1k.",sample_size,".mayla.2023-01-17.txt",sep=""), header=T))
}


# list of correlation types in each matrix (one for m, one for beta)
corrs = list(b.pear, m.pear, spear, kend, hoef, b.dist, m.dist, mic)
corrs.labels = c("b.pear", "m.pear", "spear", "kend", "hoef", "b.dist", "m.dist", "mic")
# b.corrs = list(b.pear, spear, kend, mic, b.dist, hoef)
# b.corrs.labels = c("b.pear", "spear", "kend", "mic", "b.dist", "hoef")

# generating empty 6x6 matrix for m values
corrmat.matrix = matrix(rep(0,length(corrs)^2), nrow = length(corrs))

# loop through indices to test correlation of each matrix with each other matrix
for(i in 1:length(corrs)){
	print(paste("beginning ", corrs.labels[i]," row\n", sep=""))
    for(j in 1:length(corrs)){
        corrmat.matrix[i,j] = corrmat(as.data.frame(corrs[i]), as.data.frame(corrs[j]), abs=corr.abs, corr.method=metric)
	print(paste(corrs.labels[j], " done; ", sep=""))
}
	print(paste("\nfinished ", corrs.labels[i]," row\n", sep=""))
}

# convert to data frame, add row/col labels
corrmat.df = data.frame(corrmat.matrix)
rownames(corrmat.df) = corrs.labels
colnames(corrmat.df) = corrs.labels

while(F){
# repeat with beta values - generate empty 6x6
corrmat.b.matrix = matrix(rep(0,36), nrow = 6, ncol = 6)

# loop through indices to test correlation of each matrix with each other matrix
for(i in 1:6){
    for(j in 1:6){
	 corrmat.b.matrix[i,j] = corrmat(as.data.frame(b.corrs[i]), as.data.frame(b.corrs[j]), abs=corr.abs, corr.method=metric)
}
}

# convert to data frame, add row/col labels
corrmat.b.df = data.frame(corrmat.b.matrix)
rownames(corrmat.b.df) = b.corrs.labels
colnames(corrmat.b.df) = b.corrs.labels
}


# save as .csv files
text = "1k."
if(tenk){
	text = "10k."
}

write.table(corrmat.df, file = paste("/home/nxo9/BRCAResearch/correlations/corrmat.8x8.table.",text,sample_size,"N.with.",metric,".abs.",corr.abs,".",format(Sys.Date(), "%Y-%m-%d"),".csv",sep=""),sep=",", row.names=T, col.names=T)
# write.table(corrmat.b.df, file = paste("/home/nxo9/TumorData/corrcorr/corrmat.B.",sample.type,".",sites.size,".",num.samples,".6x6.with.",metric,".abs.",corr.abs,".", format(Sys.Date(), "%Y-%m-%d"),".csv",sep=""),sep=",", row.names=T, col.names=T)





