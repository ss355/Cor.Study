# Date: 2/5/2024

# Updating Outlier Graphs:

# For Density and Barplots:
# [Note 98 SS.Review/7.Jan11.2024.Review.60p.pdf: need to make the title and legends larger and clearer for these plots (Figure R10 and Figure R11 below)]

# 9/2/2024 Adjusting the 4th figure so that it can have >= in the title

########################################################################

# setwd("E:/R/Post.REU/Updated code and graphs")

########################################################################


# Setting up the dataframe
normal.all.BRCA.outlier.analysis.30N = data.frame(normal.all.BRCA[,1],normal.all.BRCA[,5:34])

# Checking the matrix count
outliers.coef2.all= unname(apply(normal.all.BRCA.outlier.analysis.30N[,2:31], 1, function(x) length(boxplot.stats(x, coef=2)$out))) # Mild Outliers 2IQR
outliers.coef3.all= unname(apply(normal.all.BRCA.outlier.analysis.30N[,2:31], 1, function(x) length(boxplot.stats(x, coef=3)$out))) # Extreme Outliers 3IQR
outliers.coef4.all= unname(apply(normal.all.BRCA.outlier.analysis.30N[,2:31], 1, function(x) length(boxplot.stats(x, coef=4)$out))) # 4IQR
outliers.coef5.all= unname(apply(normal.all.BRCA.outlier.analysis.30N[,2:31], 1, function(x) length(boxplot.stats(x, coef=5)$out))) # 5IQR

# Combining the matrix
normal.all.BRCA.outlier.analysis.30N = cbind(normal.all.BRCA.outlier.analysis.30N,outliers.coef2.all,outliers.coef3.all,outliers.coef4.all,outliers.coef5.all)

# Checking the outlier distribution
table(normal.all.BRCA.outlier.analysis.30N$outliers.coef2.all)
table(normal.all.BRCA.outlier.analysis.30N$outliers.coef3.all)
table(normal.all.BRCA.outlier.analysis.30N$outliers.coef4.all)
table(normal.all.BRCA.outlier.analysis.30N$outliers.coef5.all)

# Subsets to take Means
normal.all.BRCA.outliers2= normal.all.BRCA.outlier.analysis.30N[which(normal.all.BRCA.outlier.analysis.30N$outliers.coef2.all > 0),]
normal.all.BRCA.outliers3= normal.all.BRCA.outlier.analysis.30N[which(normal.all.BRCA.outlier.analysis.30N$outliers.coef3.all > 0),]
normal.all.BRCA.outliers4= normal.all.BRCA.outlier.analysis.30N[which(normal.all.BRCA.outlier.analysis.30N$outliers.coef4.all > 0),]
normal.all.BRCA.outliers5= normal.all.BRCA.outlier.analysis.30N[which(normal.all.BRCA.outlier.analysis.30N$outliers.coef5.all > 0),]

# Means
mean(normal.all.BRCA.outliers2$outliers.coef2.all)
mean(normal.all.BRCA.outliers3$outliers.coef3.all)
mean(normal.all.BRCA.outliers4$outliers.coef4.all)
mean(normal.all.BRCA.outliers5$outliers.coef5.all)
########################################################################


########################################################################
# Setting up the dataframe
normal.10k.outlier.analysis = data.frame(normal.all.BRCA[1:10000,1],normal.all.BRCA[1:10000,5:34])

# Getting the 3IQR outliers counts
outliers.coef3.10k= unname(apply(normal.10k.outlier.analysis[,2:31], 1, function(x) length(boxplot.stats(x, coef=3)$out))) # Extreme Outliers 3IQR
normal.10k.outlier.analysis = cbind(normal.10k.outlier.analysis,outliers.coef3.10k)

# Creating Subsets based on the 3IQR Outlier Counts
Subset.of.3IQR.with.0.outliers = normal.10k.outlier.analysis[which (normal.10k.outlier.analysis$outliers.coef3.10k == 0),]
Subset.of.3IQR.with.1.or.2.outliers = normal.10k.outlier.analysis[which (normal.10k.outlier.analysis$outliers.coef3.10k == 1 | normal.10k.outlier.analysis$outliers.coef3.10k == 2),]
Subset.of.3IQR.with.3.plus.outliers = normal.10k.outlier.analysis[which (normal.10k.outlier.analysis$outliers.coef3.10k >= 3),]

# First 1000 of the subsets
First.1000.of.the.3IQR.and.0.outliers = Subset.of.3IQR.with.0.outliers[1:1000,]
First.1000.of.the.3IQR.and.1.or.2.outliers = Subset.of.3IQR.with.1.or.2.outliers[1:1000,]
First.1000.of.the.3IQR.and.3.plus.outliers = Subset.of.3IQR.with.3.plus.outliers[1:1000,]

# Random 1000 of the entire Sample Size
sampleindex = sample(1:10000, 1000, replace=FALSE)
Random.1000.of.the.10k = normal.10k.outlier.analysis[sampleindex,]
########################################################################


########################################################################

# List Needed for Function
sample30N.list = list(B.pearson.10kx10k.30N,M.pearson.10kx10k.30N,Spearman.10kx10k.30N,Kendall.10kx10k.30N,Hoeffding.10kx10k.30N,B.distance.10kx10k.30N,M.distance.10kx10k.30N,MIC.10kx10k.30N)
names(sample30N.list) = c("B.pearson","M.pearson","Spearman","Kendall","Hoeffding","B.distance","M.distance","MIC")


Density.plotter.for.outlier.subsets = function(list,df,title){
  
  temp.matrix = matrix(data = NA, nrow(df),0) # Empty matrix which will cbind later
  names = names(list) # Needed for the legend of the graph
  
  colforlegend = c(seq.int(1,length(list),1)) # Colors for the graphs
  
  graphtitle = gsub("\\.", " ", title) 
  
  for (m in 1:length(list)){
    include_list = df[,1] # Lists names of the CG sites that meet the conditions of the subset
    metric = list[[m]]
    cor_scores = metric[include_list,include_list]  # Shrinking the matrix to the sites that meet the criteria
    high_count = rowSums(abs(cor_scores) >= 0.75)    # Counting the high counts
    temp.matrix = cbind(temp.matrix,high_count)     
    
  }
  
  plot(density(temp.matrix[,1]/10), lwd = 2, main =graphtitle, xlim = c(0,100), ylim = c(0,0.25), cex.main = 1.8)
  for(i in 2:length(list)){
    lines(density(temp.matrix[,i]/10), col = i, lwd = 2, xlim = c(0,100), ylim = c(0,0.25))
  }
  
  legend("top",legend = names, col = colforlegend , lwd = 2, cex = 1.5, ncol = 2, bty = "n")
  
}

pdf(file = paste("Comparison.of.different.subsets.of.the.3IQR.Outlier.Counts.div10.", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width=16, height=12, onefile = TRUE)
par(mfrow=c(2,2), cex.axis = 1.5, cex.lab = 1.5)

Density.plotter.for.outlier.subsets(sample30N.list,Random.1000.of.the.10k, "Random 1000 Sites")
Density.plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.3IQR.and.0.outliers, "3IQR Counts = 0")
Density.plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.3IQR.and.1.or.2.outliers, "3IQR Counts = 1 or 2")
Density.plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.3IQR.and.3.plus.outliers, "IQR Counts >= 3")

dev.off()

########################################################################


########################################################################

# List Needed for Function
sample30N.list = list(B.pearson.10kx10k.30N,M.pearson.10kx10k.30N,Spearman.10kx10k.30N,Kendall.10kx10k.30N,Hoeffding.10kx10k.30N,B.distance.10kx10k.30N,M.distance.10kx10k.30N,MIC.10kx10k.30N)
names(sample30N.list) = c("B.pearson","M.pearson","Spearman","Kendall","Hoeffding","B.distance","M.distance","MIC")


Bar.Plotter.for.outlier.subsets = function(list,df,title){
  
  temp.matrix = matrix(data = NA, nrow(df),0) # Empty matrix which will cbind later
  names = names(list) # Needed for the legend of the graph
  
  colforlegend = c(seq.int(1,length(list),1)) # Colors for the graphs
  
  for (m in 1:length(list)){
    include_list = df[,1] # Lists names of the CG sites that meet the conditions of the subset
    metric = list[[m]]
    cor_scores = metric[include_list,include_list]  # Shrinking the matrix to the sites that meet the criteria
    high_count = rowSums(abs(cor_scores) >= 0.75)    # Counting the high counts
    temp.matrix = cbind(temp.matrix,high_count)     
    
  }
  
  new.temp.matrix  = matrix(data = NA, nrow = 8, ncol = 10 ,0)
  for (m in 1:length(list)){
    new.temp.vector = table(cut(temp.matrix[,m], breaks = seq(0, 1000, by = 100)))
    new.temp.matrix = rbind(new.temp.matrix,new.temp.vector)
    
  }
  
  
  barplot(new.temp.matrix ,beside = T, col = colforlegend, main=title , ylim = c(0,1000), ylab= "Frequency", xlab = "Ranges",
          cex.main = 1.7, cex.names = 0.8, cex.lab = 1.2)
  
  
  legend("top",legend = names, col = colforlegend , lwd = 2, cex = 1.4, ncol = 2)
} 

# Produce The PDF
pdf(file = paste("Comparison.of.different.subsets.of.the.3IQR.Outlier.Counts.Bar.Plots.", format(Sys.Date(), "%Y-%m-%d"),".pdf"), 
    width=16, height=12, onefile = TRUE , useDingbats = FALSE)
par(mfrow=c(2,2), cex.axis = 1.5, cex.lab = 1.5)

Bar.Plotter.for.outlier.subsets(sample30N.list,Random.1000.of.the.10k, "A. Random 1000 Sites")
Bar.Plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.3IQR.and.0.outliers, "B. 3IQR Counts = 0")
Bar.Plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.3IQR.and.1.or.2.outliers, "C. 3IQR Counts = 1 or 2")
Bar.Plotter.for.outlier.subsets(sample30N.list,First.1000.of.the.3IQR.and.3.plus.outliers,  bquote(bold("D. 3IQR Counts" ~ "" >= " 3"))) # Fixed it

dev.off()
