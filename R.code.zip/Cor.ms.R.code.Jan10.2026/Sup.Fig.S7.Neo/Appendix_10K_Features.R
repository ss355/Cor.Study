# Goal is to compare the first 10K to the entire data set.
# This includes analysis from some previous code, and new analysis 

# We look at 1) Feature Type, 2) Mean, 3) Median, 4) Outliers, 5) SD, 6) Chromosome Frequency

# load packages
library(dplyr)
library(ggplot2)
library(scales)
library(matrixStats)
library(tidyr)


# read data
df1 <- read.table("BRCA.53Alive.Normal.380355cg.75col.Aug18.2022.txt", header = TRUE, sep = "\t", stringsAsFactors = FALSE, check.names = FALSE)
df2 <- read.table("gene.info.380355cg.10col.NA0.in.8data.Aug18.2022.txt", header = TRUE, sep = "\t", stringsAsFactors = FALSE, check.names = FALSE) # contains some additional info


# merge
df_merged <- cbind(df1, df2[, -(1:4), drop = FALSE])


# Create new columns based on different criteria
df_merged$beta_mean <- rowMeans(df_merged[, 5:34], na.rm = TRUE) # mean
df_merged$beta_median <- apply(df_merged[, 5:34], 1, median, na.rm = TRUE) # median
df_merged$beta_vars <- rowVars(as.matrix(df_merged[, 5:34]), na.rm = TRUE) # variance
df_merged$beta_std  <- sqrt(df_merged$beta_vars) # std
df_merged$beta_outliers <- apply(as.matrix(df_merged[, 5:34]), 1, function(x) length(boxplot.stats(x, coef = 3)$out)) # outlier


# Change to the Feature Type col
df_merged$Feature_Type[df_merged$Feature_Type == "."] <- "Open_sea"


# first 10K data
first_10K <- df_merged[1:10000, , drop = FALSE] # first 10k

# Jan 10, 2026 Mayla brought up the color swap issue in the Figure S7. 
# # Just change this line from "First_10K" to "10K" will solve the problem. 
# first_10K$Source <- "First_10K"
first_10K$Source <- "10K"
df_merged$Source <- "All"

##################################################
# Feature Type
##################################################

# deal with list issue
first_10K$Feature_Type  <- as.character(unlist(first_10K$Feature_Type))
df_merged$Feature_Type <- as.character(unlist(df_merged$Feature_Type))

pct_df <- bind_rows(first_10K, df_merged) %>%
  dplyr::count(Source, Feature_Type) %>%
  group_by(Source) %>%
  mutate(pct = n / sum(n) * 100) %>%
  ungroup()

pct_df$Source[is.na(pct_df$Source)] <- "All"

fet_wide <- pct_df %>%
  select(Feature_Type, Source, pct) %>%
  pivot_wider(names_from = Source, values_from = pct, values_fill = 0) %>%
  arrange(Feature_Type)

write.csv(fet_wide, file = "Feature_Type_Distribution_First10K_vs_All.csv", row.names = FALSE)



p_fet <- ggplot(pct_df, aes(x = Feature_Type, y = pct, fill = Source)) +
  geom_col(position = position_dodge(width = 1)) +
  labs(
    title = "Feature_Type Distribution: First 10K vs Full Sample",
    x = "Feature Type",
    y = "Percentage of Rows"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# save pdf
ggsave(filename = "Feature_Type_Distribution_First10K_vs_All.pdf", plot = p_fet, width    = 8, height   = 6, units    = "in")


##################################################
# Mean 
##################################################


first_10K$beta_mean  <- as.numeric(unlist(first_10K$beta_mean))
first_10K$beta_mean <- as.numeric(unlist(first_10K$beta_mean))

mean_bins <- seq(0, 1, by = 0.1) # mean is contained in here

mean_pct <- bind_rows(
  first_10K %>% transmute(Source = "10K", value = beta_mean),
  df_merged %>% transmute(Source = "All", value = beta_mean)
) %>%
  mutate(bin = cut(value, breaks = mean_bins, include.lowest = TRUE, right = FALSE)) %>%
  dplyr::count(Source, bin) %>%
  group_by(Source) %>%
  mutate(pct = n / sum(n) * 100) %>%
  ungroup()

mean_wide <- mean_pct %>%
  select(Source, bin, pct) %>%
  pivot_wider(names_from = Source, values_from = pct, values_fill = 0) %>%
  arrange(bin)

write.csv(mean_wide, "beta_mean_bins_pct.csv", row.names = FALSE) # write csv


p_mean <- ggplot(mean_pct, aes(x = bin, y = pct, fill = Source)) +
  geom_col(position = position_dodge(width = 0.85), width = 0.8) +
  labs(
    title = "beta_mean distribution: 10K vs All",
    x = "beta_mean bin",
    y = "Percent of rows"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggsave("beta_mean_bins_pct.pdf", plot = p_mean, width = 9, height = 6)
p_mean


##################################################
# Median
##################################################

median_bins <- seq(0, 1, by = 0.1)

median_pct <- bind_rows(
  first_10K %>% transmute(Source = "10K", value = beta_median),
  df_merged %>% transmute(Source = "All", value = beta_median)
) %>%
  mutate(bin = cut(value, breaks = median_bins, include.lowest = TRUE, right = FALSE)) %>%
  dplyr::count(Source, bin) %>%
  group_by(Source) %>%
  mutate(pct = n / sum(n) * 100) %>%
  ungroup()

# Writing CSV
median_wide <- median_pct %>%
  select(Source, bin, pct) %>%
  pivot_wider(names_from = Source, values_from = pct, values_fill = 0) %>%
  arrange(bin)

write.csv(median_wide, "beta_median_bins_pct.csv", row.names = FALSE)

# Plotting
p_median <- ggplot(median_pct, aes(x = bin, y = pct, fill = Source)) +
  geom_col(position = position_dodge(width = 0.85), width = 0.8) +
  labs(
    title = "beta_median distribution: 10K vs All",
    x = "beta_median bin",
    y = "Percent of rows"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggsave("beta_median_bins_pct.pdf", plot = p_median, width = 9, height = 6)
p_median


##################################################
# Outliers
##################################################

outlier_pct <- bind_rows(
  first_10K %>% transmute(Source = "10K", out = as.integer(beta_outliers)),
  df_merged %>% transmute(Source = "All", out = as.integer(beta_outliers))
) %>%
  mutate(
    Range = case_when(
      out == 0 ~ "0",
      out %in% 1:2 ~ "1 to 2",
      out >= 3 ~ "3+"
    )
  ) %>%
  dplyr::count(Source, Range, name = "Freq") %>%
  group_by(Source) %>%
  mutate(Percentage = round(Freq / sum(Freq) * 100, 3)) %>%
  ungroup() %>%
  mutate(Range = factor(Range, levels = c("0", "1 to 2", "3+")))

# Writing CSV
outlier_wide <- outlier_pct %>%
  select(Source, Range, Percentage) %>%
  pivot_wider(names_from = Source, values_from = Percentage, values_fill = 0) %>%
  arrange(Range)

write.csv(outlier_wide, "beta_outliers_bins_pct.csv", row.names = FALSE)

# Plotting
p_out <- ggplot(outlier_pct, aes(x = Range, y = Percentage, fill = Source)) +
  geom_col(position = position_dodge(width = 0.85), width = 0.8) +
  labs(
    title = "Outliers distribution: 10K vs All",
    x = "Outlier count bucket",
    y = "Percent of rows"
  ) +
  theme_minimal()

ggsave("beta_outliers_bins_pct.pdf", plot = p_out, width = 8, height = 5)


##################################################
# Standard Deviation
##################################################

sd_df <- bind_rows(
  first_10K %>% transmute(Source = "10K", sd = beta_std),
  df_merged %>% transmute(Source = "All", sd = beta_std)
) %>%
  mutate(
    Range = case_when(
      sd < 0.05 ~ "SD < 0.05",
      sd >= 0.05 & sd <= 0.10 ~ "0.05 <= SD <= 0.1",
      sd > 0.10 ~ "SD > 0.1"
    ),
    Range = factor(Range, levels = c("SD < 0.05", "0.05 <= SD <= 0.1", "SD > 0.1"))
  ) %>%
  dplyr::count(Source, Range) %>%
  group_by(Source) %>%
  mutate(Percentage = round(n / sum(n) * 100, 3)) %>%
  ungroup()

# Writing CSV
sd_wide <- sd_df %>%
  select(Range, Source, Percentage) %>%
  pivot_wider(names_from = Source, values_from = Percentage, values_fill = 0) %>%
  arrange(Range)

write.csv(sd_wide, "beta_std_comparison.csv", row.names = FALSE)

# Plotting
p_sd <- ggplot(sd_df, aes(x = Range, y = Percentage, fill = Source)) +
  geom_col(position = position_dodge(width = 0.85), width = 0.8) +
  labs(
    title = "Standard deviation distribution: 10K vs All",
    x = "Std range",
    y = "Percent of rows"
  ) +
  theme_minimal()

ggsave("beta_std_comparison.pdf", plot = p_sd, width = 9, height = 6)
p_sd


##################################################
# Chromosome Frequency
##################################################

first_10K$Chromosome  <- as.character(unlist(first_10K$Chromosome))
df_merged$Chromosome  <- as.character(unlist(df_merged$Chromosome))

chr_pct <- bind_rows(
  first_10K %>% transmute(Source = "10K", Chromosome),
  df_merged %>% transmute(Source = "All", Chromosome)
) %>%
  dplyr::count(Source, Chromosome) %>%
  group_by(Source) %>%
  mutate(pct = n / sum(n) * 100) %>%
  ungroup()

# Write CSV
chr_wide <- chr_pct %>%
  select(Chromosome, Source, pct) %>%
  pivot_wider(names_from = Source, values_from = pct, values_fill = 0) %>%
  arrange(Chromosome)

write.csv(chr_wide, "chromosome_bins_pct.csv", row.names = FALSE)

# Plotting
p_chr <- ggplot(chr_pct, aes(x = Chromosome, y = pct, fill = Source)) +
  geom_col(position = position_dodge(width = 0.85), width = 0.8) +
  labs(
    title = "Chromosome Distribution: 10K vs All",
    x = "Chromosome",
    y = "Percent of rows"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggsave("chromosome_bins_pct.pdf", plot = p_chr, width = 9, height = 6)
p_chr


##################################################
# Combined Plot
##################################################

library(gridExtra)

combined_plot <- grid.arrange(
  p_fet, p_mean,
  p_median, p_out,
  p_sd, p_chr,
  ncol = 2
)

ggsave(
  "All_Distributions_3x2.pdf",
  combined_plot,
  width = 12,
  height = 15
)





