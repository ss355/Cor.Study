# Want to generate a Table that looks at the distribution of the variance count for the data
library(data.table)

Frequency.counter = function(df){
  LowSD = sum(df[1,2])
  MidSD = sum(df[2,2])
  HighSD = sum(df[3:nrow(df),2])
  Freq = c(LowSD,MidSD,HighSD)
  Range = c("SD < 0.05", "0.05 <= SD <= 0.1", "SD > 0.1")
  finaldf = setDT(data.table(Range,Freq))
  finaldf[, Percentage := round(Freq / sum(Freq) * 100, digits = 3)]
}

# Start with the 10K - Generate a Vector with the count
Variances = rowVars(as.matrix(normal.all.BRCA[1:10000,5:34]))
SD = sqrt(unname(Variances))
SD = as.data.frame(table(cut(SD,breaks=seq(0,0.3 ,by=0.05))))
SD = Frequency.counter(SD)

# Now for All 
Variances.ALL = rowVars(as.matrix(normal.all.BRCA[,5:34]))
SD.ALL = sqrt(unname(Variances.ALL))
SD.ALL = as.data.frame(table(cut(SD.ALL,breaks=seq(0,0.3 ,by=0.05))))
SD.ALL = Frequency.counter(SD.ALL)


SD.Comparison = cbind(SD,SD.ALL)
write.csv(SD.Comparison, file = "SD.Frequency.Comparison.table.1.4.2024.csv")