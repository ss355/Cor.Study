library(ggplot2)
library(cowplot) # for plot_grid function

# loading in 10k x 10k matrices
# updated to reflect move in home directory on maylas computer
# code now run from directory /home/mayla/Documents/TexasStateREU/BRCAResearch/corrmatScatterplots/binplot.regen.2024-02-28
b.dist <- read.table("../30N.corr.matrices/b.dist.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
b.pear <- read.table("../30N.corr.matrices/b.pear.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
hoef <- read.table("../30N.corr.matrices/hoef.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
kend <- read.table("../30N.corr.matrices/kend.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
m.dist <- read.table("../30N.corr.matrices/m.dist.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
m.pear <- read.table("../30N.corr.matrices/m.pear.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
mic <- read.table("../30N.corr.matrices/mic.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
spear <- read.table("../30N.corr.matrices/spear.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)

# flattened vector from upper triangle
b.dist.vec <- as.vector(b.dist[upper.tri(b.dist, diag=F)])
b.pear.vec <- as.vector(b.pear[upper.tri(b.pear, diag=F)])
hoef.vec <- as.vector(hoef[upper.tri(hoef, diag=F)])
kend.vec <- as.vector(kend[upper.tri(kend, diag=F)])
m.dist.vec <- as.vector(m.dist[upper.tri(m.dist, diag=F)])
m.pear.vec <- as.vector(m.pear[upper.tri(m.pear, diag=F)])
mic.vec <- as.vector(mic[upper.tri(mic, diag=F)])
spear.vec <- as.vector(spear[upper.tri(spear, diag=F)])

corr_vecs <- data.frame(b.pear = b.pear.vec, m.pear = m.pear.vec, spear = spear.vec, kend = kend.vec, hoef = hoef.vec, b.dist = b.dist.vec, m.dist = m.dist.vec, mic = mic.vec)
abs.corr_vecs <- abs(corr_vecs)


###########################################
# out of these three functions, this file only uses the second one
###########################################

rast.grid <- function(data, x, y, xlab, ylab, xmin, ymin, bins, maxCount){
    b = ceiling(bins/2)
    if(maxCount == "max"){
        plot <- ggplot(data, aes(x = x, y = y)) +
            geom_bin2d(breaks = c(-b:b)/b) +
            stat_bin2d(geom = "raster", breaks = c(-b:b)/b) +
            scale_fill_viridis_c(option = "H") +
            xlim(xmin,1) +
            ylim(ymin,1) +
            xlab(xlab) +
            ylab(ylab) +
            coord_fixed(ratio = 1)
    }else{
        plot <- ggplot(data, aes(x = x, y = y)) +
            geom_bin2d(breaks = c(-b:b)/b) +
            stat_bin2d(geom = "raster", breaks = c(-b:b)/b) +
            scale_fill_viridis_c(option = "H", limits = c(1,maxCount)) +
            xlim(xmin,1) +
            ylim(ymin,1) +
            xlab(xlab) +
            ylab(ylab) +
            coord_fixed(ratio = 1)
    }
    return(plot)
}


### only need this one function
rast.grid.bins <- function(data, x, y, xlab, ylab, title, xmin, ymin, xbins, ybins, maxCount){
	xb = ceiling(xbins/2)
	yb = ceiling(ybins/2)
	if(maxCount == "max"){
		plot <- ggplot(data, aes(x = x, y = y)) +
		geom_bin2d(breaks = list(x = c(-xb:xb)/xb, y = c(-yb:yb)/yb)) +
		stat_bin2d(geom = "raster", breaks = list(x = c(-xb:xb)/xb, y = c(-yb:yb)/yb)) +
		scale_fill_viridis_c(option = "H") +
		xlim(xmin,1) +
		ylim(ymin,1) +
		xlab(xlab) +
		ylab(ylab) +
		ggtitle(title) +
		theme(plot.title = element_text(hjust = 0.5)) + # centers the title
		coord_fixed(ratio = 1)
	}else{
		plot <- ggplot(data, aes(x = x, y = y)) +
		geom_bin2d(breaks = list(x = c(-xb:xb)/xb, y = c(-yb:yb)/yb)) +
		stat_bin2d(geom = "raster", breaks = list(x = c(-xb:xb)/xb, y = c(-yb:yb)/yb)) +
		scale_fill_viridis_c(option = "H", limits = c(1,maxCount)) +
		xlim(xmin,1) +
		ylim(ymin,1) +
		xlab(xlab) +
		ylab(ylab) +
		ggtitle(title) +
		theme(plot.title = element_text(hjust = 0.5)) + # centers the title
		coord_fixed(ratio = 1)
	}
	return(plot)
}


text.grid <- function(data, x, y, xlab, ylab, xmin, ymin, bins, maxCount){
    b = ceiling(bins/2)
    if(maxCount == "max"){
        plot <- ggplot(data, aes(x = x, y = y)) + 
            geom_bin2d(breaks = c(-b:b)/b) + 
            stat_bin2d(geom = "text", aes(label = after_stat(count)), breaks = c(-b:b)/b) + 
            scale_fill_viridis_c() + 
            xlim(xmin,1) + 
            ylim(ymin,1) +
            xlab(xlab) +
            ylab(ylab) +
            coord_fixed(ratio = 1)
    }else{
        plot <- ggplot(data, aes(x = x, y = y)) + 
            geom_bin2d(breaks = c(-b:b)/b) + 
            stat_bin2d(geom = "text", aes(label = after_stat(count)), breaks = c(-b:b)/b) + 
            scale_fill_viridis_c(limits = c(1,maxCount)) + 
            xlim(xmin,1) + 
            ylim(ymin,1) +
            xlab(xlab) +
            ylab(ylab) +
            coord_fixed(ratio = 1)
    }
    return(plot)
}

####################################################################################################
# making plots
####################################################################################################

# using version of grid plot function to scale bins to equal resolution regardless of x/y bounds

# first figure
# b.pear on x-axis
bP.mP <- rast.grid.bins(corr_vecs, corr_vecs$b.pear, corr_vecs$m.pear, "B.Pearson", "M.Pearson", "A. cor = 0.9651", -1, -1, 200, 200, "max") # max just under 1500

# b.dist on x axis
bD.mD <- rast.grid.bins(corr_vecs, corr_vecs$b.dist, corr_vecs$m.dist, "B.Distance", "M.Distance", "B. cor = 0.9780", 0, 0, 400, 400, "max") # max just over 4000

# m.pear on x axis
mP.mD <- rast.grid.bins(corr_vecs, corr_vecs$m.pear, corr_vecs$m.dist, "M.Pearson", "M.Distance", "C. cor = 0.9285", -1, 0, 200, 400, "max") # max just under 800

# kend on x axis
K.H <- rast.grid.bins(corr_vecs, corr_vecs$kend, corr_vecs$hoef, "Kendall", "Hoeffding", "D. cor = 0.8356", -1, -0.25, 200, 320, "max")

# kend on x axis
K.S <- rast.grid.bins(corr_vecs, corr_vecs$kend, corr_vecs$spear, "Kendall", "Spearman", "E. cor = 0.9902", -1, -1, 200, 200, "max") # max just over 4000

# m.pear on x axis
mP.S <- rast.grid.bins(corr_vecs, corr_vecs$m.pear, corr_vecs$spear, "M.Pearson", "Spearman", "F. cor = 0.7968", -1, -1, 200, 200, "max") # max just over 800

figure <- plot_grid(bP.mP, bD.mD, mP.mD, K.H, K.S, mP.S, ncol = 2, nrow = 3, rel_heights = c(3,2,3))
pdf("high.cor.bin.plots.2024-04-26.pdf", height = 9, width = 8)
print(figure)
dev.off()

# second figure
# kend on x axis
K.bD <- rast.grid.bins(corr_vecs, corr_vecs$kend, corr_vecs$b.dist, "Kendall", "B.Distance", "A. cor = 0.7108", -1, 0, 200, 400, "max") # max just under 1500

# m.pear on x axis
mP.H <- rast.grid.bins(corr_vecs, corr_vecs$m.pear, corr_vecs$hoef, "M.Pearson", "Hoeffding", "C. cor = 0.6240", -1, -0.25, 200, 320, "max")

# mic on x axis
bP.M <- rast.grid.bins(corr_vecs, corr_vecs$m.pear, corr_vecs$mic, "M.Pearson", "MIC", "B. cor = 0.4901", -1, 0, 200, 400, "max")

# hoef on x axis
H.M <- rast.grid.bins(corr_vecs, corr_vecs$hoef, corr_vecs$mic, "Hoeffding", "MIC", "D. cor = 0.7284", -0.25, 0, 320, 400, "max")


figure <- plot_grid(K.bD, bP.M, NULL, NULL, mP.H, H.M, ncol = 2, nrow = 3, rel_heights = c(1,-0.5, 2))
pdf("low.cor.bin.plots.2024-04-26.pdf", height = 7, width = 9)
print(figure)
dev.off()




###################################################
##### Other code not in use
###################################################
while F{ # not using this code rn but didn't want to delete it
# E, F, G, and H
# m.pear on x axis
mP.S <- rast.grid.bins(corr_vecs, corr_vecs$m.pear, corr_vecs$spear, "m.pear", "spear", -1, -1, 200, 200, "max") # max just over 800

# kend on x axis
K.S <- rast.grid.bins(corr_vecs, corr_vecs$kend, corr_vecs$spear, "kend", "spear", -1, -1, 200, 200, "max") # max just over 4000

# m.pear on x axis
mP.H <- rast.grid.bins(corr_vecs, corr_vecs$m.pear, corr_vecs$hoef, "m.pear", "hoef", -1, -0.25, 200, 320, "max")

# spear on x axis
S.H <- rast.grid.bins(corr_vecs, corr_vecs$spear, corr_vecs$hoef, "spear", "hoef", -1, -0.25,  200, 320, "max")

figure <- plot_grid(mP.S, K.S, mP.H, S.H, ncol = 2, nrow = 2, rel_heights = c(8,5))
pdf("mP.S-K.S-mP.H-S.H.2024-03-08.pdf", height = 5, width = 7)
print(figure)
dev.off()


# last three plots together
# mic on x axis
bP.M <- rast.grid.bins(corr_vecs, corr_vecs$m.pear, corr_vecs$mic, "m.pear", "mic", -1, 0, 200, 400, "max")

# kend on x axis
K.M <- rast.grid.bins(corr_vecs, corr_vecs$kend, corr_vecs$mic, "kend", "mic", -1, 0, 200, 400, "max")

# hoef on x axis
H.M <- rast.grid.bins(corr_vecs, corr_vecs$hoef, corr_vecs$mic, "hoef", "mic", -0.25, 0, 320, 400, "max")

figure <- plot_grid(bP.M, K.M, H.M, ncol = 2, nrow = 2, rel_heights = c(4,5))
pdf("bP.M-K.M-H.M.2024-03-08.pdf", height = 4, width = 7)
print(figure)
dev.off()
}


