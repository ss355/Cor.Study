#### Recreation of Mayla's version of 3.7.2
## This includes 4 visuals


### 11/10/24 Edits - Primarily visual edits to the last two bar plots


### 1 The Scatterplot

# setwd("E:/R/Post.REU/Mayla.Recreation")


library(matrixStats)

get.b.m.both <- function(m_data, b_data, thresh){
  
  diag(b_data) <- 0
  diag(m_data) <- 0
  
  # Lets Us Grab the High in B Only and the High in Both
  high.b =  which(b_data >= thresh | b_data < -thresh)
  associated.high.m.counts = which(m_data[high.b] >= thresh| m_data[high.b] < -thresh)
  associated.not.high.m.counts = which(m_data[high.b] < thresh & m_data[high.b] >= -thresh)
  
  both.high.cells = high.b[associated.high.m.counts]
  b.only.count.cells = high.b[associated.not.high.m.counts]
  
  # Grab the M Only High
  high.m = which(m_data >= thresh | m_data < -thresh) # This is what Mayla has but this might need to be fixed
  associated.not.high.b.counts = which(b_data[high.m] < thresh & b_data[high.m] >= -thresh)
  m.only.count.cells = high.m[associated.not.high.b.counts]
  
  # Matrix for High in Both
  m1 = b_data
  m1[both.high.cells] <- 100
  both.count.vector = rowSums(m1 == 100.0000) # Getting the sum vectors of the high counts 
  
  # High B
  m2 = b_data
  m2[b.only.count.cells] <- 100
  b.only.count.vector = rowSums(m2 == 100.0000)
  
  # High M
  m3 = b_data
  m3[m.only.count.cells] <- 100
  m.only.count.vector = rowSums(m3 == 100.0000)
  
  # Now to Create a few more vectors of note
  b.high.vector = both.count.vector + b.only.count.vector
  m.high.vector = both.count.vector + m.only.count.vector
  # total.count = both.count.vector + b.only.count.vector + m.only.count.vector (No longer think this is useful)
  
  diff = b.high.vector - m.high.vector
  ratio.b.m.only = b.only.count.vector / m.only.count.vector
  ratio.b.m = b.high.vector / m.high.vector
  
  # Scrapping the first 10000 CG site names
  indices = which(normal.all.BRCA$Composite.Element.REF %in% rownames(b_data)) 
  row_names = normal.all.BRCA[indices,1]
  
  # Getting other features
  IQR3.count = unname(apply(normal.all.BRCA[indices,5:34], 1, function(x) length(boxplot.stats(x, coef=3)$out)))
  variances = rowVars(as.matrix(normal.all.BRCA[indices,5:34]))
  std = sqrt(variances)
  
  # Note Im not including the Total Counts
  matrix = data.frame(cbind(row_names, unname(both.count.vector), unname(b.only.count.vector), b.high.vector, unname(m.only.count.vector), m.high.vector,
                            diff, round(unname(ratio.b.m), digits = 4),round(unname(ratio.b.m.only), digits = 4), IQR3.count, std))
                      
  colnames(matrix) = c("CG.Site", "Both.Counts", "B.Only.Counts", "High.B.Counts", "M.Only.Counts", "High.M.Counts" , "B.M.Diff" , "B.M.Ratio", "B.Only.M.Only.Ratio", "IQR.3.Count", "Standard.Deviation")
  
  return(matrix)
  
}
  
# Now Lets Grab Pearson and Distance So That We Can Plot the Scatterplots
pearson.table = get.b.m.both(M.pearson.10kx10k.30N, B.pearson.10kx10k.30N, 0.75)
dist.table = get.b.m.both(M.distance.10kx10k.30N,B.distance.10kx10k.30N,0.75)


# Save the PDF
pdf(file=paste ("Scatterplots.of.High.Row.Counts.in.B.vs.M.Mayla.Recreation.", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width = 18)
par(mfrow = c(1, 2))

# Pearson
plot(pos.pearson.table$High.B.Counts , pos.pearson.table$High.M.Counts, xlab = "B.Pearson", 
     ylab = "M.Pearson", ylim = c(0,2200), xlim = c(0,2200), main = "Pearson: High Row Counts using B and M Values", cex.main = 1.8,
     cex.lab = 1.3, cex.axis = 1.1)
abline(0,1, col = "green", lwd = 2)
polygon(c(100,2500,2500,200), c(0,0,1250,100), col=rgb(1, .94, .28, 0.5), border=NA)
polygon(c(0,0,1250,100), c(100,2500,2500,200), col=rgb(1, .28, .94, 0.3), border=NA)

# Distance
plot(dist.table$High.B.Counts , dist.table$High.M.Counts, xlab = "B.Pearson", 
     ylab = "M.Pearson", ylim = c(0,2200), xlim = c(0,2200), main = "Pearson: High Row Counts using B and M Values", cex.main = 1.8,
     cex.lab = 1.3, cex.axis = 1.1)
abline(0,1, col = "green", lwd = 2)
polygon(c(100,2500,2500,200), c(0,0,1250,100), col=rgb(1, .94, .28, 0.5), border=NA)
polygon(c(0,0,1250,100), c(100,2500,2500,200), col=rgb(1, .28, .94, 0.3), border=NA)

dev.off()

###############################################################################################################################################################################
###############################################################################################################################################################################

# Next is to recreate the new 80 / 20 tables - One can review Mayla's code to understand the lofic of our approach. 

####### Pearson
# B Dominant sites
b.dom.pear.orig = subset(pearson.table, as.numeric(B.M.Diff) >= 100 & as.numeric(B.M.Ratio) >= 2)

b.dom.m.pear = M.pearson.10kx10k.30N[unlist(b.dom.pear.orig["CG.Site"]), unlist(b.dom.pear.orig["CG.Site"])]
b.dom.b.pear = B.pearson.10kx10k.30N[unlist(b.dom.pear.orig["CG.Site"]), unlist(b.dom.pear.orig["CG.Site"])]
b.dom.pear.inner.comp = get.b.m.both(b.dom.m.pear, b.dom.b.pear, 0.75)


pear.b.dom.both.counts = sum(as.integer(b.dom.pear.orig$Both.Counts)) - sum(as.integer(b.dom.pear.inner.comp$Both.Counts))/2 # 241042
pear.b.dom.b.only.counts = sum(as.integer(b.dom.pear.orig$B.Only.Counts)) - sum(as.integer(b.dom.pear.inner.comp$B.Only.Counts))/2 # 448362
pear.b.dom.m.only.counts = sum(as.integer(b.dom.pear.orig$M.Only.Counts)) - sum(as.integer(b.dom.pear.inner.comp$M.Only.Counts))/2 # 116176



# M Dominant sites
##### Note that the choice of as.integer vs as.numeric affects the results
m.dom.pear.orig = subset(pearson.table, as.numeric(B.M.Diff) <= -100 & as.numeric(B.M.Ratio) <= 1/2)

m.dom.m.pear = M.pearson.10kx10k.30N[unlist(m.dom.pear.orig["CG.Site"]), unlist(m.dom.pear.orig["CG.Site"])]
m.dom.b.pear = B.pearson.10kx10k.30N[unlist(m.dom.pear.orig["CG.Site"]), unlist(m.dom.pear.orig["CG.Site"])]
m.dom.pear.inner.comp = get.b.m.both(m.dom.m.pear, m.dom.b.pear, 0.75)

pear.m.dom.both.counts = sum(as.integer(m.dom.pear.orig$Both.Counts)) - sum(as.integer(m.dom.pear.inner.comp$Both.Counts))/2 # 42811
pear.m.dom.b.only.counts = sum(as.integer(m.dom.pear.orig$B.Only.Counts)) - sum(as.integer(m.dom.pear.inner.comp$B.Only.Counts))/2 # 2600
pear.m.dom.m.only.counts = sum(as.integer(m.dom.pear.orig$M.Only.Counts)) - sum(as.integer(m.dom.pear.inner.comp$M.Only.Counts))/2 # 116176


####### Distance
# B Dominant Sites
b.dom.dist.orig = subset(dist.table, as.numeric(B.M.Diff) >= 100 & as.numeric(B.M.Ratio) >= 2)

b.dom.m.dist = M.distance.10kx10k.30N[unlist(b.dom.dist.orig["CG.Site"]), unlist(b.dom.dist.orig["CG.Site"])]
b.dom.b.dist = B.distance.10kx10k.30N[unlist(b.dom.dist.orig["CG.Site"]), unlist(b.dom.dist.orig["CG.Site"])]
b.dom.dist.inner.comp = get.b.m.both(b.dom.m.dist, b.dom.b.dist, 0.75)


dist.b.dom.both.counts = sum(as.integer(b.dom.dist.orig$Both.Counts)) - sum(as.integer(b.dom.dist.inner.comp$Both.Counts))/2 #265023
dist.b.dom.b.only.counts = sum(as.integer(b.dom.dist.orig$B.Only.Counts)) - sum(as.integer(b.dom.dist.inner.comp$B.Only.Counts))/2 #522386
dist.b.dom.m.only.counts = sum(as.integer(b.dom.dist.orig$M.Only.Counts)) - sum(as.integer(b.dom.dist.inner.comp$M.Only.Counts))/2 #11508


# M Dominant sites
m.dom.dist.orig = subset(dist.table, as.numeric(B.M.Diff) <= -100 & as.numeric(B.M.Ratio) <= 1/2)

m.dom.m.dist = M.distance.10kx10k.30N[unlist(m.dom.dist.orig["CG.Site"]), unlist(m.dom.dist.orig["CG.Site"])]
m.dom.b.dist = B.distance.10kx10k.30N[unlist(m.dom.dist.orig["CG.Site"]), unlist(m.dom.dist.orig["CG.Site"])]
m.dom.dist.inner.comp = get.b.m.both(m.dom.m.dist, m.dom.b.dist, 0.75)

dist.m.dom.both.counts = sum(as.integer(m.dom.dist.orig$Both.Counts)) - sum(as.integer(m.dom.dist.inner.comp$Both.Counts))/2 # 1411
dist.m.dom.b.only.counts = sum(as.integer(m.dom.dist.orig$B.Only.Counts)) - sum(as.integer(m.dom.dist.inner.comp$B.Only.Counts))/2 #33947
dist.m.dom.m.only.counts = sum(as.integer(m.dom.dist.orig$M.Only.Counts)) - sum(as.integer(m.dom.dist.inner.comp$M.Only.Counts))/2  #83052




###### Values for % - Grabbed from Mayla - Can be found in Table 10 which has been reproduced
pear.b.only = 796938
pear.m.only = 270975
pear.both = 1522198

dist.b.only = 760453
dist.m.only = 223122
dist.both = 1579861

# Now To Build The Matrix 
metric = c('Pearson','Pearson','Distance','Distance')
criteria = c('B-Dominant','M-Dominant','B-Dominant','M-Dominant')
num_sites = as.numeric(c(nrow(b.dom.pear.orig),nrow(m.dom.pear.orig),nrow(b.dom.dist.orig),nrow(m.dom.dist.orig)))
b.only = c(pear.b.dom.b.only.counts,pear.m.dom.b.only.counts,dist.b.dom.b.only.counts,dist.m.dom.b.only.counts)
b.only.per = round(b.only / c(pear.b.only,pear.b.only,dist.b.only,dist.b.only) * 100, digits = 3)
m.only = c(pear.b.dom.m.only.counts,pear.m.dom.m.only.counts,dist.b.dom.m.only.counts,dist.m.dom.m.only.counts)
m.only.per = round( m.only / c(pear.m.only,pear.m.only,dist.m.only, dist.m.only) * 100, digits = 3)
both = c(pear.b.dom.both.counts,pear.m.dom.both.counts,dist.b.dom.both.counts,dist.m.dom.both.counts)
both.per =  round(both / c(pear.both,pear.both,dist.both,dist.both) * 100 ,digits = 3)
B.dom.vs.M.dom = cbind(metric,criteria,num_sites,b.only, b.only.per,m.only, m.only.per,both, both.per)

write.csv(B.dom.vs.M.dom, file = "B.dom.vs.M.dom.table.mayla.recreation.csv")

###############################################################################################################################################################################
###############################################################################################################################################################################
library(ggplot2)
library(gridExtra)
# Now lets recreate the two bar graphs

plot_frequency_iqr <- function(data, column_name, plot_title = "Frequency Plot") {
  # Create a frequency table
  freq_table <- as.data.frame(table(data[[column_name]]))
  colnames(freq_table) <- c("category", "count")
  
  # Calculate the percentage
  freq_table$percentage <- (freq_table$count / sum(freq_table$count)) * 100
  
  # Create the bar plot
  ggplot(freq_table, aes(x = category, y = percentage)) +
    geom_bar(stat = "identity", fill = "tomato1") +
    geom_text(aes(label = count), vjust = -0.2) +  # Add count labels above the bars
    labs(y = "Percentage (%)", x = "Outlier Count ", title = plot_title) +  # Add title
    theme_minimal()+
    ylim(0, 100) + 
    scale_x_discrete(limits = as.character(0:6)) +
    theme(plot.title = element_text(hjust = 0.5))
}


plot1 = plot_frequency_iqr(b.dom.pear.orig,"IQR.3.Count", "Outliers for Pearson B-Dominant Sites")
plot2 = plot_frequency_iqr(m.dom.pear.orig,"IQR.3.Count", "Outliers for Pearson M-Dominant Sites")
plot3 = plot_frequency_iqr(b.dom.dist.orig,"IQR.3.Count", "Outliers for Distance B-Dominant Sites")
plot4 = plot_frequency_iqr(m.dom.dist.orig,"IQR.3.Count", "Outliers for Distance M-Dominant Sites")
plot5 = plot_frequency_iqr(pearson.table,"IQR.3.Count", "Outliers for all 10 K Sites")

# Save the PDF
pdf(file=paste ("Histogram.for.outliers.of.dominant.sites.mayla.recreation.", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width = 12)
grid.arrange(plot1, plot2, plot3, plot4, plot5, ncol = 2, nrow = 3)
dev.off()



plot_frequency_std <- function(data, column_name, plot_title = "Frequency Plot") {
  # Convert the column to numeric if it's not already numeric
  if (!is.numeric(data[[column_name]])) {
    data[[column_name]] <- as.numeric(as.character(data[[column_name]]))
    if (any(is.na(data[[column_name]]))) {
      stop("The column contains non-numeric values that could not be converted.")
    }
  }
  
  # Define breaks from 0 to 0.3 with 0.05 intervals
  breaks <- seq(0, 0.3, by = 0.05)
  
  # Create bins using the cut function with the defined breaks
  data$bins <- cut(data[[column_name]], breaks = breaks, include.lowest = TRUE, right = FALSE)
  
  # Create a frequency table based on the bins
  freq_table <- as.data.frame(table(data$bins))
  colnames(freq_table) <- c("category", "count")
  
  # Calculate the percentage
  freq_table$percentage <- (freq_table$count / sum(freq_table$count)) * 100
  
  # Create the bar plot
  ggplot(freq_table, aes(x = category, y = percentage)) +
    geom_bar(stat = "identity", fill = "tomato1") +
    geom_text(aes(label = ifelse(count == 0, NA, count)), vjust = -0.2) +  # Hide labels for counts of 0
    labs(y = "Percentage (%)", x = "Bins", title = plot_title) +  # Add title and change x-axis label
    theme_minimal() +
    ylim(0, 100) + 
    theme(plot.title = element_text(hjust = 0.5))
}


plot1 = plot_frequency_std(b.dom.pear.orig,"Standard.Deviation", "Standard.Deviation for Pearson B-Dominant Sites")
plot2 = plot_frequency_std(m.dom.pear.orig,"Standard.Deviation", "Standard.Deviation for Pearson M-Dominant Sites")
plot3 = plot_frequency_std(b.dom.dist.orig,"Standard.Deviation", "Standard.Deviation for Distance B-Dominant Sites")
plot4 = plot_frequency_std(m.dom.dist.orig,"Standard.Deviation", "Standard.Deviation for Distance M-Dominant Sites")
plot5 = plot_frequency_std(pearson.table,"Standard.Deviation", "Standard.Deviation for all 10 K Sites")

# Save the PDF
pdf(file=paste ("Histogram.for.standard.deviation.of.dominant.sites.mayla.recreation.", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width = 12)
grid.arrange(plot1, plot2, plot3, plot4, plot5, ncol = 2, nrow = 3)
dev.off()

