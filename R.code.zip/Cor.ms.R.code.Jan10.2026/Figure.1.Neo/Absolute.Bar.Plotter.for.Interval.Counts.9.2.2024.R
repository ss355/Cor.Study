# 2/5/2024
# Editing Graphs For Paper

# This is a redo of the sample size impact bar graphs
# This addresses: 
# 1) [11/28/2023 Reminder: regenerate this figure to have 3 plots in one row or one column 6.Nov29.2023.SS.Review note 7]
# 2) [Note 51/52 SS.Review/7.Jan11.2024.Review.60p.pdf: when re-doing these plots, make title and legend larger so that font size of axis labels/title/legend/everything matches the font size of the paper text]

# Note this needs to be run in a workspace that has all the matrices

# Edit 9/2/2024 - Adjusted to only be the upper triangle

################################
# Lists Needed

# 10N List
sample10N.list = list(B.pearson.10kx10k.10N,M.pearson.10kx10k.10N,Spearman.10kx10k.10N,Kendall.10kx10k.10N,Hoeffding.10kx10k.10N,B.distance.10kx10k.10N,M.distance.10kx10k.10N,MIC.10kx10k.10N)
names(sample10N.list) = c("B.pearson.10kx10k.10N","M.pearson.10kx10k.10N","Spearman.10kx10k.10N","Kendall.10kx10k.10N","Hoeffding.10kx10k.10N","B.distance.10kx10k.10N","M.distance.10kx10k.10N","MIC.10kx10k.10N")

# 30N List
sample30N.list = list(B.pearson.10kx10k.30N,M.pearson.10kx10k.30N,Spearman.10kx10k.30N,Kendall.10kx10k.30N,Hoeffding.10kx10k.30N,B.distance.10kx10k.30N,M.distance.10kx10k.30N,MIC.10kx10k.30N)
names(sample30N.list) = c("B.pearson.10kx10k.30N","M.pearson.10kx10k.30N","Spearman.10kx10k.30N","Kendall.10kx10k.30N","Hoeffding.10kx10k.30N","B.distance.10kx10k.30N","M.distance.10kx10k.30N","MIC.10kx10k.30N")

# 53N List
sample53N.list = list(B.pearson.10kx10k.53N,M.pearson.10kx10k.53N,Spearman.10kx10k.53N,Kendall.10kx10k.53N,Hoeffding.10kx10k.53N,B.distance.10kx10k.53N,M.distance.10kx10k.53N,MIC.10kx10k.53N)
names(sample53N.list) = c("B.pearson.10kx10k.53N","M.pearson.10kx10k.53N","Spearman.10kx10k.53N","Kendall.10kx10k.53N","Hoeffding.10kx10k.53N","B.distance.10kx10k.53N","M.distance.10kx10k.53N","MIC.10kx10k.53N")

################################
# Function Needed

Absolute.Bar.plotter.to.compare.range = function(list,title){
  
  final.matrix = matrix(nrow = length(list), ncol = 8) # This will store the counts
  
  names = as.character(names(list)) # The Name of the Matrices

  # Remove suffix based on different patterns
  names <- ifelse(grepl("\\.10kx10k.10N$", names), sub("\\.10kx10k.10N$", "", names),
            ifelse(grepl("\\.10kx10k.30N$", names), sub("\\.10kx10k.30N$", "", names),
            ifelse(grepl("\\.10kx10k.53N$", names), sub("\\.10kx10k.53N$", "", names), names)))
  
  
  intervals = c(-1,-0.75,-0.5,-0.25,0,0.25,0.5,0.75,1) # Intervals needed
  
  graphtitle = gsub("\\.", " ", title) # For The Title of the Graph
  
  for (n in 1:length(list) ){
    df = list[[n]] #Grabbing the nth matrix
    df = abs(df)   # Absolue Value
    
    df[lower.tri(df, diag = FALSE)] <- 4 # Setting to remove lower diag
    
    for ( m in 1:8) {  #Doing a process similiar to the 8x8
      if(m<8){
        interested.cells = which( df >= intervals[m] & df < intervals[m+1])
        total.count = length(interested.cells)
        final.matrix[n,m] = total.count
      }
      
      else{
        interested.cells = which( df >= intervals[m] & df <= intervals[m+1])
        total.count = length(interested.cells)
        final.matrix[n,m] = total.count
        
      }
    }
    
  }
  colnames(final.matrix) = c("[-1,-0.75)","[-0.75,-0.5)","[-0.5,-0.25)","[-0.25,0)","[0,0.25)","[0.25,0.5)","[0.5,0.75)" ,"[0.75,1]")
  
  colforlegend = c(seq.int(1,length(list),1)) 
  
  new.final = final.matrix[, !apply(final.matrix == 0, 2, all)] # Removes columns of zero
  
  barplot(new.final, beside = T,  main = graphtitle, col = colforlegend, cex.main = 4, cex.lab = 2, cex.axis = 2)
  legend("topright",legend = names, col = colforlegend , lwd = 2, cex = 2, box.lwd = 0)
  
  return(barplot)
}

pdf(file = paste("Absolute.Bar.Plots.Sample.Sizes.No.Lower.Tri.", format(Sys.Date(), "%Y-%m-%d"),".pdf"), width=20, height=10, onefile = TRUE)
par(mfrow = c(1,3), cex.axis=2.)
# 10N 
Absolute.Bar.plotter.to.compare.range(sample10N.list,"10N")
# 30N
Absolute.Bar.plotter.to.compare.range(sample30N.list,"30N")
# 53N
Absolute.Bar.plotter.to.compare.range(sample53N.list,"53N")
dev.off()



