#/home/mayla/Documents/TexasStateREU/BRCAResearch/barplot.regen.2024-02-28
# set up with all the required barplot tables in the same folder
# to find these tables on leap server, see /home/nxo9/BRCAResearch/eight.x.eight/barplots
# tables there all use the same name as they are referenced by in this file

# work here modeled after what is done in make.barplots but only the makePlots function is modified
# since tables are already generated/saved

# going to need to rename columns from loaded tables
colnames = c("[-1,-0.75)", "[-0.75, -0.5)", "[-0.5,-0.25)", "[-0.25,0)", "[0,0.25)", "[0.25,0.5)", "[0.5,0.75)", "[0.75,1]")

# also redoing row names to match neo's names
rownames = c("B.pearson", "M.pearson", "Spearman", "Kendall", "Hoeffding", "B.distance", "M.distance", "MIC")

# load in tables and rename columns:
abs.spear <- read.csv(file = "/home/nxo9/BRCAResearch/eight.x.eight/barplots/abs.spear.30.8.eight.by.eight.barplot.table.2023-02-08.csv", header=T, row.names = 'X1')[-1]
colnames(abs.spear) <- colnames
rownames(abs.spear) <- rownames

hoef.intv <- read.csv(file = "/home/nxo9/BRCAResearch/eight.x.eight/barplots/hoef.30.hoef.intv.eight.by.eight.barplot.table.2022-11-22.csv", header = T, row.names = 'X1')[-1]
colnames(hoef.intv) <- colnames
rownames(hoef.intv) <- rownames

# colors for plotting
colforlegend = c(seq.int(1,8,1))

pdf(file = "hoef.spear.comparison.barplots.regen.2024-07-04.pdf", height = 8, width = 15)
par(mfrow = c(1,2), mar = c(6, 5, 3, 2), xpd = T)
# abs spear
barplot(as.matrix(abs.spear[,1:ncol(abs.spear)-1]), beside=T, col=colforlegend, ylim=c(0,max(hoef.intv[,1:ncol(hoef.intv)-1])), main = "A. abs(Spearman) scores in [0.75,1]", legend.text = T, args.legend = list(x=20, y=max(hoef.intv[,1:ncol(hoef.intv)-1]), bty="n", cex=1), las=2)

# hoef intv
barplot(as.matrix(hoef.intv[,1:ncol(hoef.intv)-1]), beside=T, col=colforlegend, ylim=c(0,max(hoef.intv[,1:ncol(hoef.intv)-1])), main = "B. Hoeffding scores in [0.25,1]", legend.text = T, args.legend = list(x=20, y=max(hoef.intv[,1:ncol(hoef.intv)-1]), bty="n", cex=1), las=2)

dev.off()



