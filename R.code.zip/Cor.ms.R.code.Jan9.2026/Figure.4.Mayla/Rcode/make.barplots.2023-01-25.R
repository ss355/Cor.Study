source("barplot.functions.2022-11-21.R")


intervals <- makeIntervals()
# [ "1" [-1, -0.75), "2" [-0.75, -0.5), "3" [-0.5, -0.25), "4" [-0.25, 0), "5" [0, 0.25), "6" [0.25, 0.5), "7" [0.5, 0.75), "8" [0.75, 1] ]


while(F){ # remove this loop to re-generate these tables
system.time(corrmats <- loadTables(10))
# [ "b.pear.10", "m.pear.10", "spear.10", "kend.10", "hoef.10", "b.dist.10", "m.dist.10", "mic.10" ]

# m.pear [0.75, 1] 10 N
system.time(tables <- makeTable(corrmats[2],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# m.pear [-1,0.75) 10 N
system.time(tables <- makeTable(corrmats[2],intervals[1],corrmats,intervals))
makePlots(tables[2],intervals[1])
makePlots(tables[1],intervals[1])

# mic [0.75, 1] 10 N
system.time(tables <- makeTable(corrmats[8],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# m.dist [0.75, 1] 10 N
system.time(tables <- makeTable(corrmats[7],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# hoef [0.25, 1] 10 N
hoef.intv <- list("hoef.intv" = c(0.25,1.01))
system.time(tables <- makeTable(corrmats[5],hoef.intv[1],corrmats,intervals))
makePlots(tables[2],hoef.intv[1])
makePlots(tables[1],hoef.intv[1])
}

system.time(corrmats <- loadTables(30))
# [ "b.pear.30", "m.pear.30", "spear.30", "kend.30", "hoef.30", "b.dist.30", "m.dist.30", "mic.30" ]

while(F){ # remove this loop to re-generate these tables
# b.pear [0.75, 1] 30N
system.time(tables <- makeTable(corrmats[1],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# b.pear [-1, -0.75] 30N
system.time(tables <- makeTable(corrmats[1],intervals[1],corrmats,intervals))
makePlots(tables[2],intervals[1])
makePlots(tables[1],intervals[1])

# spear [0.75, 1] 30N
system.time(tables <- makeTable(corrmats[3],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# spear [-1, -0.75] 30N
system.time(tables <- makeTable(corrmats[3],intervals[1],corrmats,intervals))
makePlots(tables[2],intervals[1])
makePlots(tables[1],intervals[1])

# kend [0.75, 1] 30N
system.time(tables <- makeTable(corrmats[4],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# kend [-1, -0.75] 30N
system.time(tables <- makeTable(corrmats[4],intervals[1],corrmats,intervals))
makePlots(tables[2],intervals[1])
makePlots(tables[1],intervals[1])

# b.dist [0.75, 1] 30N
system.time(tables <- makeTable(corrmats[6],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])
}

####### experimental plots for things *not* highly correlated (eg, stuff from middling intervals)
mid.intv.pos.neg <- list("mid.intv.pos.neg" = c(-0.75, 0.75))

while(FALSE){ # remove this loop to re-generate these tables
# m.pear [-0.75, 0.75] 30N
system.time(tables <- makeTable(corrmats[2],mid.intv.pos.neg[1],corrmats,intervals))
makePlots(tables[2],mid.intv.pos.neg[1])
makePlots(tables[1],mid.intv.pos.neg[1])

# b.pear [-0.75, 0.75] 30N
system.time(tables <- makeTable(corrmats[1],mid.intv.pos.neg[1],corrmats,intervals))
makePlots(tables[2],mid.intv.pos.neg[1])
makePlots(tables[1],mid.intv.pos.neg[1])

# spear [-0.75, 0.75] 30N
system.time(tables <- makeTable(corrmats[3],mid.intv.pos.neg[1],corrmats,intervals))
makePlots(tables[2],mid.intv.pos.neg[1])
makePlots(tables[1],mid.intv.pos.neg[1])


# kend [-0.75, 0.75] 30N
system.time(tables <- makeTable(corrmats[4],mid.intv.pos.neg[1],corrmats,intervals))
makePlots(tables[2],mid.intv.pos.neg[1])
makePlots(tables[1],mid.intv.pos.neg[1])

# b.dist [0, 0.75] 30N
mid.intv.pos <- list("mid.intv.pos" = c(0,0.75))
system.time(tables <- makeTable(corrmats[6],mid.intv.pos[1],corrmats,intervals))
makePlots(tables[2],mid.intv.pos[1])
makePlots(tables[1],mid.intv.pos[1])

# m.dist [0, 0.75] 30N
system.time(tables <- makeTable(corrmats[7],mid.intv.pos[1],corrmats,intervals))
makePlots(tables[2],mid.intv.pos[1])
makePlots(tables[1],mid.intv.pos[1])

# mic [0, 0.75] 30N
system.time(tables <- makeTable(corrmats[8],mid.intv.pos[1],corrmats,intervals))
makePlots(tables[2],mid.intv.pos[1])
makePlots(tables[1],mid.intv.pos[1])

# hoef [-0.25, 0.25] 30N
mid.intv.hoef <- list("hoef.mid.intv" = c(-0.25, 0.25))
system.time(tables <- makeTable(corrmats[5],mid.intv.hoef[1],corrmats,intervals))
makePlots(tables[2],mid.intv.hoef[1])
makePlots(tables[1],mid.intv.hoef[1])
}

while(F){ # remove this loop to re-generate these tables
# m.pear [0.75, 1] 30 N
system.time(tables <- makeTable(corrmats[2],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# m.pear [-1,0.75) 30 N
system.time(tables <- makeTable(corrmats[2],intervals[1],corrmats,intervals))
makePlots(tables[2],intervals[1])
makePlots(tables[1],intervals[1])

# mic [0.75, 1] 30 N
system.time(tables <- makeTable(corrmats[8],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# m.dist [0.75, 1] 30 N
system.time(tables <- makeTable(corrmats[7],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# hoef [0.25, 1] 30 N
hoef.intv <- list("hoef.intv" = c(0.25,1.01))
system.time(tables <- makeTable(corrmats[5],hoef.intv[1],corrmats,intervals))
makePlots(tables[2],hoef.intv[1])
makePlots(tables[1],hoef.intv[1])
}

# trying a thing where we do spearmans but with absolute value 
# (highly negative and positive together in one plot) 
# so that we can compare it with hoeffding

# NOTE: this changes spearman to positive in list of all the 30N tables; if this list is used for future barplots not requiring positive spearmans, comment this out
# corrmats[3][[1]]=abs(corrmats[3][[1]]) # i haven't tested this in this file yet but it worked when I did it this way in terminal mode
# abs(spear) [0.75, 1] 30N
#system.time(tables <- makeTable(abs(corrmats[3][[1]]),intervals[8], corrmats, intervals))
#makePlots(tables[2], intervals[8])
#makePlots(tables[1], intervals[8])
# I couldn't get these ^ to work

while(F){
system.time(corrmats <- loadTables(53))
# [ "b.pear.53", "m.pear.53", "spear.53", "kend.53", "hoef.53", "b.dist.53", "m.dist.53", "mic.53" ]

# m.pear [0.75, 1] 53 N
system.time(tables <- makeTable(corrmats[2],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# m.pear [-1,0.75) 53 N
system.time(tables <- makeTable(corrmats[2],intervals[1],corrmats,intervals))
makePlots(tables[2],intervals[1])
makePlots(tables[1],intervals[1])

# mic [0.75, 1] 53 N
system.time(tables <- makeTable(corrmats[8],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# m.dist [0.75, 1] 53 N
system.time(tables <- makeTable(corrmats[7],intervals[8],corrmats,intervals))
makePlots(tables[2],intervals[8])
makePlots(tables[1],intervals[8])

# hoef [0.25, 1] 53 N
hoef.intv <- list("hoef.intv" = c(0.25,1.01))
system.time(tables <- makeTable(corrmats[5],hoef.intv[1],corrmats,intervals))
makePlots(tables[2],hoef.intv[1])
makePlots(tables[1],hoef.intv[1])
}
