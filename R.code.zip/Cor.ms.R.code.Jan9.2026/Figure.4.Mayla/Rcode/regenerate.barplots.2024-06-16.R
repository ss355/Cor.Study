# /home/mayla/Documents/TexasStateREU/BRCAResearch/barplot.regen.2024-02-28
# set up with all the required barplot tables in the same folder
# to find these tables on leap server, see /home/nxo9/BRCAResearch/eight.x.eight/barplots
# tables there all use the same name as they are referenced by in this file

# work here modeled after what is done in make.barplots but only the makePlots function is modified
# since tables are already generated/saved

# going to need to rename columns from loaded tables
colnames = c("[-1,-0.75)", "[-0.75, -0.5)", "[-0.5,-0.25)", "[-0.25,0)", "[0,0.25)", "[0.25,0.5)", "[0.5,0.75)", "[0.75,1]")

# also redoing row names to match neo's names
rownames = c("B.pearson", "M.pearson", "Spearman", "Kendall", "Hoeffding", "B.distance", "M.distance", "MIC")

# load in tables and rename columns:
b.pear.neg <- read.csv(file = "/home/nxo9/BRCAResearch/eight.x.eight/barplots/b.pear.30.1.eight.by.eight.barplot.table.2023-01-25.csv", header=T, row.names = 'X1')[-1]
colnames(b.pear.neg) <- colnames
rownames(b.pear.neg) <- rownames

b.pear.pos <- read.csv(file = "/home/nxo9/BRCAResearch/eight.x.eight/barplots/b.pear.30.8.eight.by.eight.barplot.table.2023-01-25.csv", header = T, row.names = 'X1')[-1]
colnames(b.pear.pos) <- colnames
rownames(b.pear.pos) <- rownames

kend.neg <- read.csv(file = "/home/nxo9/BRCAResearch/eight.x.eight/barplots/kend.30.1.eight.by.eight.barplot.table.2023-01-25.csv", header = T, row.names = 'X1')[-1]
colnames(kend.neg) <- colnames
rownames(kend.neg) <- rownames

m.pear.neg <- read.csv(file = "/home/nxo9/BRCAResearch/eight.x.eight/barplots/m.pear.30.1.eight.by.eight.barplot.table.2022-11-22.csv", header = T, row.names = 'X1')[-1]
colnames(m.pear.neg) <- colnames
rownames(m.pear.neg) <- rownames

m.pear.pos <- read.csv(file = "/home/nxo9/BRCAResearch/eight.x.eight/barplots/m.pear.30.8.eight.by.eight.barplot.table.2022-11-22.csv", header = T, row.names = 'X1')[-1]
colnames(m.pear.pos) <- colnames
rownames(m.pear.pos) <- rownames

spear.neg <- read.csv(file = "/home/nxo9/BRCAResearch/eight.x.eight/barplots/spear.30.1.eight.by.eight.barplot.table.2023-01-25.csv", header = T, row.names = 'X1')[-1]
colnames(spear.neg) <- colnames
rownames(spear.neg) <- rownames

# colors for plotting
colforlegend = c(seq.int(1,8,1))

pdf(file = "manuscript.section.3.4.barplots.regen.2024-07-04.pdf", height = 12, width = 9)
par(mfrow = c(3,2), mar = c(6, 5, 5, 7), xpd = T)
# m.pear.pos
#barplot(t(m.pear.pos[,1:ncol(m.pear.pos)-1]), beside=T, col=colforlegend, main = "C. M Pearson scores in [0.75,1]", legend.text = T, args.legend = list(x=95, y=max(b.pear.pos[,1:ncol(b.pear.pos)-1]), bty="n", cex=1), las=2)
barplot(as.matrix(m.pear.pos[,1:ncol(m.pear.pos)-1]), beside=T, col=colforlegend, ylim=c(0,max(b.pear.pos[,1:ncol(b.pear.pos)-1])), main = "A. M.Pearson scores in [0.75,1]", legend.text = T, args.legend = list(x=20, y=max(b.pear.pos[,1:ncol(b.pear.pos)-1]), bty="n", cex=1), las=2)

# b.pear.pos
#barplot(t(b.pear.pos[,1:ncol(b.pear.pos)-1]), beside=T, col=colforlegend, main = "D. B Pearson scores in [0.75,1]", legend.text = T, args.legend = list(x=95, y=max(b.pear.pos[,1:ncol(b.pear.pos)-1]), bty="n", cex=1), las = 2)
barplot(as.matrix(b.pear.pos[,1:ncol(b.pear.pos)-1]), beside=T, col=colforlegend, ylim=c(0,max(b.pear.pos[,1:ncol(b.pear.pos)-1])), main = "B. B.Pearson scores in [0.75,1]", legend.text = T, args.legend = list(x=20, y=max(b.pear.pos[,1:ncol(b.pear.pos)-1]), bty="n", cex=1), las=2)

# m.pear.neg
#barplot(t(m.pear.neg[,1:ncol(m.pear.neg)-1]), beside=T, col=colforlegend, main = "A. M Pearson scores in [-1,-0.75)", legend.text = T, args.legend = list(x=95, y=max(b.pear.neg[,1:ncol(b.pear.neg)-1]), bty="n", cex=1), las=2)
barplot(as.matrix(m.pear.neg[,1:ncol(m.pear.neg)-1]), beside=T, col=colforlegend, ylim=c(0,max(b.pear.neg[,1:ncol(b.pear.neg)-1])), main = "C. M.Pearson scores in [-1,-0.75)", legend.text = T, args.legend = list(x=95, y=max(b.pear.neg[,1:ncol(b.pear.neg)-1]), bty="n", cex=1), las=2)

# b.pear.neg
#barplot(t(b.pear.neg[,1:ncol(b.pear.neg)-1]), beside=T, col=colforlegend, main = "B. B Pearson scores in [-1,-0.75)", legend.text = T, args.legend = list(x=95, y=max(b.pear.neg[,1:ncol(b.pear.neg)-1]), bty="n", cex=1), las=2)
barplot(as.matrix(b.pear.neg[,1:ncol(b.pear.neg)-1]), beside=T, col=colforlegend, ylim=c(0,max(b.pear.neg[,1:ncol(b.pear.neg)-1])), main = "D. B.Pearson scores in [-1,-0.75)", legend.text = T, args.legend = list(x=95, y=max(b.pear.neg[,1:ncol(b.pear.neg)-1]), bty="n", cex=1), las=2)

# spear.neg
#barplot(t(spear.neg[,1:ncol(spear.neg)-1]), beside=T, col=colforlegend, main = "E. Spearman scores in [-1,-0.75)", legend.text = T, args.legend = list(x=95, y=max(spear.neg[,1:ncol(spear.neg)-1]), bty="n", cex=1), las=2)
barplot(as.matrix(spear.neg[,1:ncol(spear.neg)-1]), beside=T, col=colforlegend, ylim=c(0,max(spear.neg[,1:ncol(spear.neg)-1])), main = "E. Spearman scores in [-1,-0.75)", legend.text = T, args.legend = list(x=95, y=max(spear.neg[,1:ncol(spear.neg)-1]), bty="n", cex=1), las=2)

# kend.neg
#barplot(t(kend.neg[,1:ncol(kend.neg)-1]), beside=T, col=colforlegend, main = "F. Kendall scores in [-1,-0.75)", legend.text = T, args.legend = list(x=95, y=max(kend.neg[,1:ncol(kend.neg)-1]), bty="n", cex=1), las=2)
barplot(as.matrix(kend.neg[,1:ncol(kend.neg)-1]), beside=T, col=colforlegend, ylim=c(0,max(kend.neg[,1:ncol(kend.neg)-1])), main = "F. Kendall scores in [-1,-0.75)", legend.text = T, args.legend = list(x=95, y=max(kend.neg[,1:ncol(kend.neg)-1]), bty="n", cex=1), las=2)

dev.off()



