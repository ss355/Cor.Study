loadTables <- function(sampleSize){ # loads 10k x 10k correlation matrices for a specified sample size (from 10, 30, 53)
    b.pear <- as.matrix(read.table(file = paste("/home/nxo9/BRCAResearch/correlations/txt.tables/b.pear.",as.character(sampleSize),".mayla.2022-09-30.txt",sep=""),header=T))
    m.pear <- as.matrix(read.table(file = paste("/home/nxo9/BRCAResearch/correlations/txt.tables/m.pear.",as.character(sampleSize),".mayla.2022-09-30.txt",sep=""),header=T))
    spear <- as.matrix(read.table(file = paste("/home/nxo9/BRCAResearch/correlations/txt.tables/spear.",as.character(sampleSize),".mayla.2022-09-30.txt",sep=""),header=T))
    kend <- as.matrix(read.table(file = paste("/home/nxo9/BRCAResearch/correlations/txt.tables/kend.",as.character(sampleSize),".mayla.2022-09-30.txt",sep=""),header=T))
    hoef <- as.matrix(read.table(file = paste("/home/nxo9/BRCAResearch/correlations/txt.tables/hoef.",as.character(sampleSize),".mayla.2022-09-30.txt",sep=""),header=T))
    b.dist <- as.matrix(read.table(file = paste("/home/nxo9/BRCAResearch/correlations/txt.tables/b.dist.",as.character(sampleSize),".mayla.2022-10-01.txt",sep=""),header=T))
    m.dist <- as.matrix(read.table(file = paste("/home/nxo9/BRCAResearch/correlations/txt.tables/m.dist.",as.character(sampleSize),".mayla.2022-10-01.txt",sep=""),header=T))
    mic <- as.matrix(read.table(file = paste("/home/nxo9/BRCAResearch/correlations/txt.tables/mic.",as.character(sampleSize),".mayla.2022-09-30.txt",sep=""),header=T))

    corrmats <- list(b.pear, m.pear, spear, kend, hoef, b.dist, m.dist, mic)
    names(corrmats) <- list(paste("b.pear.",sampleSize,sep=""), paste("m.pear.",sampleSize,sep=""), paste("spear.",sampleSize,sep=""), paste("kend.",sampleSize,sep=""), paste("hoef.",sampleSize,sep=""), paste("b.dist.",sampleSize,sep=""), paste("m.dist.",sampleSize, sep=""), paste("mic.",sampleSize,sep=""))

    corrmats
}

makeIntervals <- function(){
    intervals <- list(c(-1,-.75),c(-.75,-.5),c(-.5,-.25),c(-.25,0),c(0,.25),c(.25,.5),c(.5,.75),c(.75,1.01))
    names(intervals) <- list("1", "2", "3", "4", "5", "6", "7", "8")

    intervals
}

formatNames <- function(intvals) {
  names = character(length(intvals)+1)
  for (i in 1:length(intvals)) {
    names[i] = paste("[", intvals[[i]][1], ", ", intvals[[i]][2], ")", sep = "")
  }
  names[length(intvals)+1] = "Sum"
  names
}

addRowNames <- function(df) {
  output = data.frame(matrix(0, nrow = dim(df)[1], ncol = dim(df)[2]+1))
  output[,2:dim(output)[2]] = df
  output[,1] = rownames(df)
  colnames(output)[2:dim(output)[2]] = colnames(df)
  output
}

# returns vector with each element in the list of correlations, valued 1 if within the interval and -1 if not within the interval
corr.one.intv <- function(interval, vect) { -sign((vect - interval[1])*(vect-interval[2]+10^(-7)))+1 }

# returns matrix with len(intervals) columns and len(vect) rows, each row has exactly one 1 corresponding to the correct interval for that vector element
corr.all.intv <- function(intervals, vect) { sign(sapply(intervals, corr.one.intv, vect)) }

# converts matrix into a list of upper triangle correlations - by default does not include diagonal
upperTriVect <- function(mat) { unlist(mat[upper.tri(mat)]) }

# inputs for seedMat and seedInterval should be list elements, returns a list with two tables, [[1]] is the raw counts, [[2]] is percentages
makeTable <- function(seedMat, seedInterval, mats, intervals){
    seedVect = sign(corr.one.intv(seedInterval[[1]], upperTriVect(seedMat[[1]])))
  
    finalTable = data.frame(matrix(0, nrow = length(mats), ncol = length(intervals)+1))
    for(i in 1:length(mats)) {  
        finalTable[i,1:length(intervals)] = seedVect %*% corr.all.intv(intervals, upperTriVect(mats[[i]])) 
        # seedVect is 1 X 10K, corr.all.intv() produces 10K X length(intervals), output is 1 X length(intervals) for each corr mat
    }
    
    finalTable[,length(intervals)+1] = rowSums(finalTable)
    finalTable = as.data.frame(finalTable)
    rownames(finalTable) = names(mats)
    colnames(finalTable) = formatNames(intervals)

    finalTablePerc = 100*finalTable/sum(seedVect)

    tables = list(finalTable, finalTablePerc)
    names(tables) = list(names(seedMat),paste(names(seedMat),".perc",sep=""))

    tables
}

makePlots <- function(table, seedInterval){
    colors = c("red", "orange", "yellow", "green","gray","blue","purple", "black")

    pdf(file = paste("/home/nxo9/BRCAResearch/eight.x.eight/barplots/",names(table),".",names(seedInterval),".eight.x.eight.barplot.by.corr.",Sys.Date(),".pdf", sep=""))
    barplot(t(as.matrix(table[[1]])[,1:ncol(table[[1]])-1]), beside=T, col=colors, main = paste(seedInterval[[1]][1], seedInterval[[1]][2], names(table), sep=" "), legend.text = T, args.legend = list(x="topleft",cex=0.7), las=2)
    dev.off()

    pdf(file = paste("/home/nxo9/BRCAResearch/eight.x.eight/barplots/",names(table),".",names(seedInterval),".eight.x.eight.barplot.by.intv.", Sys.Date(),".pdf", sep=""))
    barplot((as.matrix(table[[1]])[,1:ncol(table[[1]])-1]), beside=T, col=colors, main = paste(seedInterval[[1]][1], seedInterval[[1]][2], names(table), sep=" "), legend.text = T, args.legend = list(x="topleft",cex=0.7), las=2)
    dev.off()

    write.csv(addRowNames(table[[1]]), file = paste("/home/nxo9/BRCAResearch/eight.x.eight/barplots/",names(table),".",names(seedInterval),".eight.by.eight.barplot.table.",Sys.Date(), ".csv", sep = ""))
}


# system.time(corrmats <- loadTables(30))
#    user  system elapsed 
# 278.078  13.337 291.900
# typeof(corrmats)
# [1] "list"
# length(corrmats)
# [1] 8
# names(corrmats)
# [1] "b.pear.30" "m.pear.30" "spear.30"  "kend.30"   "hoef.30"   "b.dist.30"
# [7] "m.dist.30" "mic.30"   
# dim(corrmats[[1]])
# [1] 10000 10000

# intervals <- makeIntervals()
# typeof(intervals)
# [1] "list"
# length(intervals)
# [1] 8
# names(intervals)
# [1] "1" "2" "3" "4" "5" "6" "7" "8"
# intervals[[1]]
# [1] -1.00 -0.75

# system.time(table <- makeTable(corrmats[1],intervals[8],corrmats,intervals))
#    user  system elapsed 
# 123.623  50.274 173.900 
# dim(tables[[1]])
# [1] 8 9
# dim(tables[[2]])
# [1] 8 9
# names(tables)
# [1] "b.pear.30"      "b.pear.30.perc"

# system.time(makePlots(tables[2],intervals[8]))
#    user  system elapsed 
#   0.043   0.003   0.051 








