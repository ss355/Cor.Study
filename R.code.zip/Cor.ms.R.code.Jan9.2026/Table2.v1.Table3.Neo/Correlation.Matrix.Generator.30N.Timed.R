# Script designed to generate 10K Matrices for 10N Data 

# Required Packages
library(Hmisc)
library(purrr)
library(minerva)
library(Pigengene)
library(BiocGenerics)
library(BiocStyle)
library(energy)

# Read in the data set
normal.all.BRCA = read.table(file = "BRCA.53Alive.Normal.380355cg.75col.Aug18.2022.txt", header = TRUE )


# Some Basic features of the data set

dim(normal.all.BRCA) # [1] 380355     75

head(normal.all.BRCA,0)
#[1] Composite.Element.REF Chromosome            Start                 End                   N1                    N2                    N3                    N4                    N5                   
#[10] N6                    N7                    N8                    N9                    N10                   N11                   N12                   N13                   N14                  
#[19] N15                   N16                   N17                   N18                   N19                   N20                   N21                   N22                   N23                  
#[28] N24                   N25                   N26                   N27                   N28                   N29                   N30                   N31                   N32                  
#[37] N33                   N34                   N35                   N36                   N37                   N38                   N39                   N40                   N41                  
#[46] N42                   N43                   N44                   N45                   N46                   N47                   N48                   N49                   N50                  
#[55] N51                   N52                   N53                   Min                   Q1                    Median                Mean                  Q3                    Max                  
#[64] NAcount               st.dev                diff.Q3Q1             outliers.coef2        outliers.coef3        HK.index              HK.gene               TSG.index             TSG.gene             
#[73] OG.index              OG.gene               methy.state          

# Take The 10 N Sample
sampledataframe.normal=normal.all.BRCA[1:10000,5:34]

#To convert B into M values
mval.sampledataframe.normal <-log2((sampledataframe.normal[,])/ (1-sampledataframe.normal[,]))

# Transposing for analysis
t.normal.sample = t(sampledataframe.normal)
t.mval.normal.sample = t(mval.sampledataframe.normal)


#Function to assign cg sites to the rows and columns
cor.label <- function(df){
  x = c(normal.all.BRCA[1:10000,1])
  colnames(df) = x
  rownames(df) = x
  return(df)
}

#Pearson
system.time(B.pearson.10kx10k.30N <- cor.label(trunc(cor(t.normal.sample, method="pearson", use="everything")*10^4)/(10^4)))
system.time(M.pearson.10kx10k.30N <- cor.label(trunc(cor(t.mval.normal.sample, method="pearson", use="everything")*10^4)/(10^4)))

write.table(B.pearson.10kx10k.30N, file = paste("B.pearson.10kx10k.30N.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)
write.table(M.pearson.10kx10k.30N, file = paste("M.pearson.10kx10k.30N.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

# Spearman
system.time(Spearman.10kx10k.30N <- cor.label(trunc(cor(t.normal.sample, method="spearman", use="everything")*10^4)/(10^4)))

write.table(Spearman.10kx10k.30N, file = paste("Spearman.10kx10k.30N.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

# Kendall
system.time(Kendall.10kx10k.30N <- cor.label(trunc(cor(t.normal.sample, method="kendall", use="everything")*10^4)/(10^4)))

write.table(Kendall.10kx10k.30N, file = paste("Kendall.10kx10k.30N.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

# Hoeffding
system.time(Hoeffding.10kx10k.30N <- cor.label(trunc(hoeffd(t.normal.sample)$D*10^4)/(10^4)))

write.table(Hoeffding.10kx10k.30N, file = paste("Hoeffding.10kx10k.30N.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

# B Distance 
system.time(B.distance.10kx10k.30N.No.Trunc <- cor.label(dcor.matrix(t.normal.sample)))
write.table(B.distance.10kx10k.30N.No.Trunc, file = paste("B.distance.10kx10k.30N.No.Trunc.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

B.distance.10kx10k.30N=trunc(B.distance.10kx10k.30N.No.Trunc*10^4)/(10^4)
write.table(B.distance.10kx10k.30N, file = paste("B.distance.10kx10k.30N.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

# M Distance 
system.time(M.distance.10kx10k.30N.No.Trunc <- cor.label(dcor.matrix(t.mval.normal.sample)))
write.table(M.distance.10kx10k.30N.No.Trunc, file = paste("M.distance.10kx10k.30N.No.Trunc", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

M.distance.10kx10k.30N=trunc(M.distance.10kx10k.30N.No.Trunc*10^4)/(10^4)
write.table(M.distance.10kx10k.30N, file = paste("M.distance.10kx10k.30N.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

# MIC
system.time(MIC.10kx10k.30N <- cor.label(trunc(as.matrix(mine(t.normal.sample, n.cores = 3, use="everything", var.thr = 0.000001)$MIC)*10^4)/10^4))

write.table(MIC.10kx10k.30N, file = paste("MIC.10kx10k.30N.", format(Sys.Date(), "%Y-%m-%d"),  ".txt", sep=""), append = F, quote = F, sep = "\t", row.names = T, col.names = T)

# Saving the workspace
save.image()

