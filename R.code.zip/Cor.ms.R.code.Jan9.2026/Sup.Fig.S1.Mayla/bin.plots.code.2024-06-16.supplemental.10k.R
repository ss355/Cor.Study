library(ggplot2)
library(cowplot) # for plot_grid function

# loading in 1k x 1k matrices
# updated to reflect move in home directory on maylas computer
# code now run from directory /home/mayla/Documents/TexasStateREU/BRCAResearch/corrmatScatterplots/binplot.regen.2024-02-28
b.dist <- read.table("../30N.corr.matrices/b.dist.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
b.pear <- read.table("../30N.corr.matrices/b.pear.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
hoef <- read.table("../30N.corr.matrices/hoef.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
kend <- read.table("../30N.corr.matrices/kend.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
m.dist <- read.table("../30N.corr.matrices/m.dist.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
m.pear <- read.table("../30N.corr.matrices/m.pear.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
mic <- read.table("../30N.corr.matrices/mic.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)
spear <- read.table("../30N.corr.matrices/spear.1k.30.mayla.2022-01-17.txt", sep="\t", header=T)

# flattened vector from upper triangle
b.dist.vec <- as.vector(b.dist[upper.tri(b.dist, diag=F)])
b.pear.vec <- as.vector(b.pear[upper.tri(b.pear, diag=F)])
hoef.vec <- as.vector(hoef[upper.tri(hoef, diag=F)])
kend.vec <- as.vector(kend[upper.tri(kend, diag=F)])
m.dist.vec <- as.vector(m.dist[upper.tri(m.dist, diag=F)])
m.pear.vec <- as.vector(m.pear[upper.tri(m.pear, diag=F)])
mic.vec <- as.vector(mic[upper.tri(mic, diag=F)])
spear.vec <- as.vector(spear[upper.tri(spear, diag=F)])

corr_vecs <- data.frame(b.pear = b.pear.vec, m.pear = m.pear.vec, spear = spear.vec, kend = kend.vec, hoef = hoef.vec, b.dist = b.dist.vec, m.dist = m.dist.vec, mic = mic.vec)
abs.corr_vecs <- abs(corr_vecs)


###########################################
# out of these three functions, this file only uses the second one
###########################################

rast.grid <- function(data, x, y, xlab, ylab, xmin, ymin, bins, maxCount){
    b = ceiling(bins/2)
    if(maxCount == "max"){
        plot <- ggplot(data, aes(x = x, y = y)) +
            geom_bin2d(breaks = c(-b:b)/b) +
            stat_bin2d(geom = "raster", breaks = c(-b:b)/b) +
            scale_fill_viridis_c(option = "H") +
            xlim(xmin,1) +
            ylim(ymin,1) +
            xlab(xlab) +
            ylab(ylab) +
            coord_fixed(ratio = 1)
    }else{
        plot <- ggplot(data, aes(x = x, y = y)) +
            geom_bin2d(breaks = c(-b:b)/b) +
            stat_bin2d(geom = "raster", breaks = c(-b:b)/b) +
            scale_fill_viridis_c(option = "H", limits = c(1,maxCount)) +
            xlim(xmin,1) +
            ylim(ymin,1) +
            xlab(xlab) +
            ylab(ylab) +
            coord_fixed(ratio = 1)
    }
    return(plot)
}


### only need this one function
rast.grid.bins <- function(data, x, y, xlab, ylab, title, xmin, ymin, xbins, ybins, maxCount){
	xb = ceiling(xbins/2)
	yb = ceiling(ybins/2)
	if(maxCount == "max"){
		plot <- ggplot(data, aes(x = x, y = y)) +
		geom_bin2d(breaks = list(x = c(-xb:xb)/xb, y = c(-yb:yb)/yb)) +
		stat_bin2d(geom = "raster", breaks = list(x = c(-xb:xb)/xb, y = c(-yb:yb)/yb)) +
		scale_fill_viridis_c(option = "H") +
		xlim(xmin,1) +
		ylim(ymin,1) +
		xlab(xlab) +
		ylab(ylab) +
		ggtitle(title) +
		theme(plot.title = element_text(hjust = 0.5)) + # centers the title
		coord_fixed(ratio = 1)
	}else{
		plot <- ggplot(data, aes(x = x, y = y)) +
		geom_bin2d(breaks = list(x = c(-xb:xb)/xb, y = c(-yb:yb)/yb)) +
		stat_bin2d(geom = "raster", breaks = list(x = c(-xb:xb)/xb, y = c(-yb:yb)/yb)) +
		scale_fill_viridis_c(option = "H", limits = c(1,maxCount)) +
		xlim(xmin,1) +
		ylim(ymin,1) +
		xlab(xlab) +
		ylab(ylab) +
		ggtitle(title) +
		theme(plot.title = element_text(hjust = 0.5)) + # centers the title
		coord_fixed(ratio = 1)
	}
	return(plot)
}


text.grid <- function(data, x, y, xlab, ylab, xmin, ymin, bins, maxCount){
    b = ceiling(bins/2)
    if(maxCount == "max"){
        plot <- ggplot(data, aes(x = x, y = y)) + 
            geom_bin2d(breaks = c(-b:b)/b) + 
            stat_bin2d(geom = "text", aes(label = after_stat(count)), breaks = c(-b:b)/b) + 
            scale_fill_viridis_c() + 
            xlim(xmin,1) + 
            ylim(ymin,1) +
            xlab(xlab) +
            ylab(ylab) +
            coord_fixed(ratio = 1)
    }else{
        plot <- ggplot(data, aes(x = x, y = y)) + 
            geom_bin2d(breaks = c(-b:b)/b) + 
            stat_bin2d(geom = "text", aes(label = after_stat(count)), breaks = c(-b:b)/b) + 
            scale_fill_viridis_c(limits = c(1,maxCount)) + 
            xlim(xmin,1) + 
            ylim(ymin,1) +
            xlab(xlab) +
            ylab(ylab) +
            coord_fixed(ratio = 1)
    }
    return(plot)
}

####################################################################################################
# making plots
####################################################################################################

# using version of grid plot function to scale bins to equal resolution regardless of x/y bounds

# first figure (S1)
# hoef on x-axis
H.mD <- rast.grid.bins(corr_vecs, corr_vecs$hoef, corr_vecs$m.dist, "Hoeffding", "M.Distance", "A. cor = 0.6735", -0.25, 0, 320, 400, "max") 
# spear on x-axis
S.H <- rast.grid.bins(corr_vecs, corr_vecs$spear, corr_vecs$hoef, "Spearman", "Hoeffding", "B. cor = 0.8029", -1, -0.25, 200, 320, "max")

figure <- plot_grid(H.mD, S.H, ncol = 2, nrow = 1)
pdf("supp.hoef.bin.plots.2024-06-16.pdf", height = 3, width = 8)
print(figure)
dev.off()

# second figure (S2)
# b.pear on x-axis
bP.S <- rast.grid.bins(corr_vecs, corr_vecs$b.pear, corr_vecs$spear, "B.Pearson", "Spearman", "A. cor = 0.7336", -1, -1, 200, 200, "max")
# m.pear on x-axis
mP.K <- rast.grid.bins(corr_vecs, corr_vecs$m.pear, corr_vecs$kend, "M.Pearson", "Kendall", "B. cor = 0.7925", -1, -1, 200, 200, "max")
# b.pear on x-axis
bP.K <- rast.grid.bins(corr_vecs, corr_vecs$b.pear, corr_vecs$kend, "B.Pearson", "Kendall", "C. cor = 0.7332", -1, -1, 200, 200, "max")

figure <- plot_grid(mP.K, bP.K, bP.S, ncol = 2, nrow = 2, rel_heights = c(1,1))
pdf("supp.kend.spear.pear.bin.plots.2024-06-16.pdf", height = 6, width = 7.5)
print(figure)
dev.off()

# third figure (S3)
# spear on x-axis
S.M <- rast.grid.bins(corr_vecs, corr_vecs$spear, corr_vecs$mic, "Spearman", "MIC", "A. cor = 0.6280", -1, 0, 200, 400, "max")
# kend on x-axis
K.M <- rast.grid.bins(corr_vecs, corr_vecs$kend, corr_vecs$mic, "Kendall", "MIC", "B. cor = 0.6318", -1, 0, 200, 400, "max")
# m.dist on x-axis
mD.M <- rast.grid.bins(corr_vecs, corr_vecs$m.dist, corr_vecs$mic, "M.Distance", "MIC", "C. cor = 0.6155", 0, 0, 400, 400, "max")

figure <- plot_grid(S.M, K.M, mD.M, ncol = 2, nrow = 2, rel_heights = c(2,3))
pdf("supp.mic.bin.plots.2024-06-16.pdf", height = 5, width = 8)
print(figure)
dev.off()

