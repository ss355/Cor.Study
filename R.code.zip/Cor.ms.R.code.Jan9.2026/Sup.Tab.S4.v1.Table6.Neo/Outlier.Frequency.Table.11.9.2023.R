# Want to generate a Table that looks at the distribution of the 3IQR outlier count for the data
library(data.table)

Frequency.counter = function(df){
  count0 = sum(df[1,2])
  count1and2 = sum(df[2:3,2])
  count3plus = sum(df[4:nrow(df),2])
  Freq = c(count0,count1and2,count3plus)
  Range = c("0", "1 to 2", "3+")
  finaldf = setDT(data.table(Range,Freq))
  finaldf[, Percentage := round(Freq / sum(Freq) * 100, digits = 3)]
}

# Start with the 10K - Generate a Vector with the count
IQR3.Count.10K = unname(apply(normal.all.BRCA[1:10000,5:34], 1, function(x) length(boxplot.stats(x, coef=3)$out)))
DF.10K = setDT(as.data.frame(table(IQR3.Count.10K)))
DF.10K = Frequency.counter(DF.10K)


# Now for All 
IQR3.Count.ALL = unname(apply(normal.all.BRCA[,5:34], 1, function(x) length(boxplot.stats(x, coef=3)$out)))
DF.ALL = setDT(as.data.frame(table(IQR3.Count.ALL)))
DF.ALL = Frequency.counter(DF.ALL)

IQR3.Comparison = cbind(DF.10K,DF.ALL)
write.csv(IQR3.Comparison, file = "IQR3.Frequency.Comparison.table.csv")

